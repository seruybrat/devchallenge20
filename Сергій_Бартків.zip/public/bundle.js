/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is not neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/css/style.scss":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/css/style.scss ***!
  \*********************************************************************************************************/
/*! namespace exports */
/*! export default [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__, __webpack_require__.n, __webpack_exports__, __webpack_require__.r, module.id, __webpack_require__.d, __webpack_require__.*, module */
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => __WEBPACK_DEFAULT_EXPORT__\n/* harmony export */ });\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ \"./node_modules/css-loader/dist/runtime/api.js\");\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);\n// Imports\n\nvar ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(true);\n// Module\n___CSS_LOADER_EXPORT___.push([module.id, \"body {\\n  font-family: Impact, Arial, sans-serif;\\n  margin: 0;\\n  padding: 0;\\n  background-color: #000; }\\n\\nbutton {\\n  position: absolute;\\n  top: 18px;\\n  left: 720px;\\n  font-family: Impact, Arial, sans-serif; }\\n\\ninput {\\n  position: absolute;\\n  top: 20px; }\\n  input:first-of-type {\\n    left: 630px; }\\n    input:first-of-type + input {\\n      left: 650px; }\\n      input:first-of-type + input + input {\\n        left: 670px; }\\n\\np {\\n  margin: 0;\\n  position: absolute;\\n  top: 18px;\\n  left: 480px;\\n  color: #fff;\\n  font-size: 20px; }\\n\", \"\",{\"version\":3,\"sources\":[\"webpack://src/css/style.scss\"],\"names\":[],\"mappings\":\"AAAA;EACE,sCAAsC;EACtC,SAAS;EACT,UAAU;EACV,sBAAsB,EAAA;;AAExB;EACE,kBAAkB;EAClB,SAAS;EACT,WAAW;EACX,sCAAsC,EAAA;;AAGxC;EACE,kBAAkB;EAClB,SAAS,EAAA;EAFX;IAII,WAAW,EAAA;IAJf;MAMM,WAAW,EAAA;MANjB;QAQQ,WAAW,EAAA;;AAMnB;EACE,SAAS;EACT,kBAAkB;EAClB,SAAS;EACT,WAAW;EACX,WAAW;EACX,eAAe,EAAA\",\"sourcesContent\":[\"body {\\n  font-family: Impact, Arial, sans-serif;\\n  margin: 0;\\n  padding: 0;\\n  background-color: #000;\\n}\\nbutton {\\n  position: absolute;\\n  top: 18px;\\n  left: 720px;\\n  font-family: Impact, Arial, sans-serif;\\n}\\n\\ninput {\\n  position: absolute;\\n  top: 20px;\\n  &:first-of-type {\\n    left: 630px;\\n    & + input {\\n      left: 650px;\\n      & + input {\\n        left: 670px;\\n      }\\n    }\\n  }\\n}\\n\\np {\\n  margin: 0;\\n  position: absolute;\\n  top: 18px;\\n  left: 480px;\\n  color: #fff;\\n  font-size: 20px;\\n}\"],\"sourceRoot\":\"\"}]);\n// Exports\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL25vZGVfbW9kdWxlcy9zYXNzLWxvYWRlci9kaXN0L2Nqcy5qcyEuL3NyYy9jc3Mvc3R5bGUuc2Nzcy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovL3JvY2tldC1nYW1lLy4vc3JjL2Nzcy9zdHlsZS5zY3NzPzcwNTciXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKHRydWUpO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiYm9keSB7XFxuICBmb250LWZhbWlseTogSW1wYWN0LCBBcmlhbCwgc2Fucy1zZXJpZjtcXG4gIG1hcmdpbjogMDtcXG4gIHBhZGRpbmc6IDA7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwOyB9XFxuXFxuYnV0dG9uIHtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogMThweDtcXG4gIGxlZnQ6IDcyMHB4O1xcbiAgZm9udC1mYW1pbHk6IEltcGFjdCwgQXJpYWwsIHNhbnMtc2VyaWY7IH1cXG5cXG5pbnB1dCB7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICB0b3A6IDIwcHg7IH1cXG4gIGlucHV0OmZpcnN0LW9mLXR5cGUge1xcbiAgICBsZWZ0OiA2MzBweDsgfVxcbiAgICBpbnB1dDpmaXJzdC1vZi10eXBlICsgaW5wdXQge1xcbiAgICAgIGxlZnQ6IDY1MHB4OyB9XFxuICAgICAgaW5wdXQ6Zmlyc3Qtb2YtdHlwZSArIGlucHV0ICsgaW5wdXQge1xcbiAgICAgICAgbGVmdDogNjcwcHg7IH1cXG5cXG5wIHtcXG4gIG1hcmdpbjogMDtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogMThweDtcXG4gIGxlZnQ6IDQ4MHB4O1xcbiAgY29sb3I6ICNmZmY7XFxuICBmb250LXNpemU6IDIwcHg7IH1cXG5cIiwgXCJcIix7XCJ2ZXJzaW9uXCI6MyxcInNvdXJjZXNcIjpbXCJ3ZWJwYWNrOi8vc3JjL2Nzcy9zdHlsZS5zY3NzXCJdLFwibmFtZXNcIjpbXSxcIm1hcHBpbmdzXCI6XCJBQUFBO0VBQ0Usc0NBQXNDO0VBQ3RDLFNBQVM7RUFDVCxVQUFVO0VBQ1Ysc0JBQXNCLEVBQUE7O0FBRXhCO0VBQ0Usa0JBQWtCO0VBQ2xCLFNBQVM7RUFDVCxXQUFXO0VBQ1gsc0NBQXNDLEVBQUE7O0FBR3hDO0VBQ0Usa0JBQWtCO0VBQ2xCLFNBQVMsRUFBQTtFQUZYO0lBSUksV0FBVyxFQUFBO0lBSmY7TUFNTSxXQUFXLEVBQUE7TUFOakI7UUFRUSxXQUFXLEVBQUE7O0FBTW5CO0VBQ0UsU0FBUztFQUNULGtCQUFrQjtFQUNsQixTQUFTO0VBQ1QsV0FBVztFQUNYLFdBQVc7RUFDWCxlQUFlLEVBQUFcIixcInNvdXJjZXNDb250ZW50XCI6W1wiYm9keSB7XFxuICBmb250LWZhbWlseTogSW1wYWN0LCBBcmlhbCwgc2Fucy1zZXJpZjtcXG4gIG1hcmdpbjogMDtcXG4gIHBhZGRpbmc6IDA7XFxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwO1xcbn1cXG5idXR0b24ge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgdG9wOiAxOHB4O1xcbiAgbGVmdDogNzIwcHg7XFxuICBmb250LWZhbWlseTogSW1wYWN0LCBBcmlhbCwgc2Fucy1zZXJpZjtcXG59XFxuXFxuaW5wdXQge1xcbiAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgdG9wOiAyMHB4O1xcbiAgJjpmaXJzdC1vZi10eXBlIHtcXG4gICAgbGVmdDogNjMwcHg7XFxuICAgICYgKyBpbnB1dCB7XFxuICAgICAgbGVmdDogNjUwcHg7XFxuICAgICAgJiArIGlucHV0IHtcXG4gICAgICAgIGxlZnQ6IDY3MHB4O1xcbiAgICAgIH1cXG4gICAgfVxcbiAgfVxcbn1cXG5cXG5wIHtcXG4gIG1hcmdpbjogMDtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogMThweDtcXG4gIGxlZnQ6IDQ4MHB4O1xcbiAgY29sb3I6ICNmZmY7XFxuICBmb250LXNpemU6IDIwcHg7XFxufVwiXSxcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOyIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/css/style.scss\n");

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/*! unknown exports (runtime-defined) */
/*! runtime requirements: module */
/*! CommonJS bailout: module.exports is used directly at 9:0-14 */
/***/ ((module) => {

"use strict";
eval("\n\n/*\n  MIT License http://www.opensource.org/licenses/mit-license.php\n  Author Tobias Koppers @sokra\n*/\n// css base code, injected by the css-loader\n// eslint-disable-next-line func-names\nmodule.exports = function (useSourceMap) {\n  var list = []; // return the list of modules as css string\n\n  list.toString = function toString() {\n    return this.map(function (item) {\n      var content = cssWithMappingToString(item, useSourceMap);\n\n      if (item[2]) {\n        return \"@media \".concat(item[2], \" {\").concat(content, \"}\");\n      }\n\n      return content;\n    }).join('');\n  }; // import a list of modules into the list\n  // eslint-disable-next-line func-names\n\n\n  list.i = function (modules, mediaQuery, dedupe) {\n    if (typeof modules === 'string') {\n      // eslint-disable-next-line no-param-reassign\n      modules = [[null, modules, '']];\n    }\n\n    var alreadyImportedModules = {};\n\n    if (dedupe) {\n      for (var i = 0; i < this.length; i++) {\n        // eslint-disable-next-line prefer-destructuring\n        var id = this[i][0];\n\n        if (id != null) {\n          alreadyImportedModules[id] = true;\n        }\n      }\n    }\n\n    for (var _i = 0; _i < modules.length; _i++) {\n      var item = [].concat(modules[_i]);\n\n      if (dedupe && alreadyImportedModules[item[0]]) {\n        // eslint-disable-next-line no-continue\n        continue;\n      }\n\n      if (mediaQuery) {\n        if (!item[2]) {\n          item[2] = mediaQuery;\n        } else {\n          item[2] = \"\".concat(mediaQuery, \" and \").concat(item[2]);\n        }\n      }\n\n      list.push(item);\n    }\n  };\n\n  return list;\n};\n\nfunction cssWithMappingToString(item, useSourceMap) {\n  var content = item[1] || ''; // eslint-disable-next-line prefer-destructuring\n\n  var cssMapping = item[3];\n\n  if (!cssMapping) {\n    return content;\n  }\n\n  if (useSourceMap && typeof btoa === 'function') {\n    var sourceMapping = toComment(cssMapping);\n    var sourceURLs = cssMapping.sources.map(function (source) {\n      return \"/*# sourceURL=\".concat(cssMapping.sourceRoot || '').concat(source, \" */\");\n    });\n    return [content].concat(sourceURLs).concat([sourceMapping]).join('\\n');\n  }\n\n  return [content].join('\\n');\n} // Adapted from convert-source-map (MIT)\n\n\nfunction toComment(sourceMap) {\n  // eslint-disable-next-line no-undef\n  var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));\n  var data = \"sourceMappingURL=data:application/json;charset=utf-8;base64,\".concat(base64);\n  return \"/*# \".concat(data, \" */\");\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcm9ja2V0LWdhbWUvLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvYXBpLmpzPzI0ZmIiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG5cbi8qXG4gIE1JVCBMaWNlbnNlIGh0dHA6Ly93d3cub3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvbWl0LWxpY2Vuc2UucGhwXG4gIEF1dGhvciBUb2JpYXMgS29wcGVycyBAc29rcmFcbiovXG4vLyBjc3MgYmFzZSBjb2RlLCBpbmplY3RlZCBieSB0aGUgY3NzLWxvYWRlclxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gKHVzZVNvdXJjZU1hcCkge1xuICB2YXIgbGlzdCA9IFtdOyAvLyByZXR1cm4gdGhlIGxpc3Qgb2YgbW9kdWxlcyBhcyBjc3Mgc3RyaW5nXG5cbiAgbGlzdC50b1N0cmluZyA9IGZ1bmN0aW9uIHRvU3RyaW5nKCkge1xuICAgIHJldHVybiB0aGlzLm1hcChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgdmFyIGNvbnRlbnQgPSBjc3NXaXRoTWFwcGluZ1RvU3RyaW5nKGl0ZW0sIHVzZVNvdXJjZU1hcCk7XG5cbiAgICAgIGlmIChpdGVtWzJdKSB7XG4gICAgICAgIHJldHVybiBcIkBtZWRpYSBcIi5jb25jYXQoaXRlbVsyXSwgXCIge1wiKS5jb25jYXQoY29udGVudCwgXCJ9XCIpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gY29udGVudDtcbiAgICB9KS5qb2luKCcnKTtcbiAgfTsgLy8gaW1wb3J0IGEgbGlzdCBvZiBtb2R1bGVzIGludG8gdGhlIGxpc3RcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcblxuXG4gIGxpc3QuaSA9IGZ1bmN0aW9uIChtb2R1bGVzLCBtZWRpYVF1ZXJ5LCBkZWR1cGUpIHtcbiAgICBpZiAodHlwZW9mIG1vZHVsZXMgPT09ICdzdHJpbmcnKSB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgICAgIG1vZHVsZXMgPSBbW251bGwsIG1vZHVsZXMsICcnXV07XG4gICAgfVxuXG4gICAgdmFyIGFscmVhZHlJbXBvcnRlZE1vZHVsZXMgPSB7fTtcblxuICAgIGlmIChkZWR1cGUpIHtcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcHJlZmVyLWRlc3RydWN0dXJpbmdcbiAgICAgICAgdmFyIGlkID0gdGhpc1tpXVswXTtcblxuICAgICAgICBpZiAoaWQgIT0gbnVsbCkge1xuICAgICAgICAgIGFscmVhZHlJbXBvcnRlZE1vZHVsZXNbaWRdID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBtb2R1bGVzLmxlbmd0aDsgX2krKykge1xuICAgICAgdmFyIGl0ZW0gPSBbXS5jb25jYXQobW9kdWxlc1tfaV0pO1xuXG4gICAgICBpZiAoZGVkdXBlICYmIGFscmVhZHlJbXBvcnRlZE1vZHVsZXNbaXRlbVswXV0pIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnRpbnVlXG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpZiAobWVkaWFRdWVyeSkge1xuICAgICAgICBpZiAoIWl0ZW1bMl0pIHtcbiAgICAgICAgICBpdGVtWzJdID0gbWVkaWFRdWVyeTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpdGVtWzJdID0gXCJcIi5jb25jYXQobWVkaWFRdWVyeSwgXCIgYW5kIFwiKS5jb25jYXQoaXRlbVsyXSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbGlzdC5wdXNoKGl0ZW0pO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gbGlzdDtcbn07XG5cbmZ1bmN0aW9uIGNzc1dpdGhNYXBwaW5nVG9TdHJpbmcoaXRlbSwgdXNlU291cmNlTWFwKSB7XG4gIHZhciBjb250ZW50ID0gaXRlbVsxXSB8fCAnJzsgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHByZWZlci1kZXN0cnVjdHVyaW5nXG5cbiAgdmFyIGNzc01hcHBpbmcgPSBpdGVtWzNdO1xuXG4gIGlmICghY3NzTWFwcGluZykge1xuICAgIHJldHVybiBjb250ZW50O1xuICB9XG5cbiAgaWYgKHVzZVNvdXJjZU1hcCAmJiB0eXBlb2YgYnRvYSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHZhciBzb3VyY2VNYXBwaW5nID0gdG9Db21tZW50KGNzc01hcHBpbmcpO1xuICAgIHZhciBzb3VyY2VVUkxzID0gY3NzTWFwcGluZy5zb3VyY2VzLm1hcChmdW5jdGlvbiAoc291cmNlKSB7XG4gICAgICByZXR1cm4gXCIvKiMgc291cmNlVVJMPVwiLmNvbmNhdChjc3NNYXBwaW5nLnNvdXJjZVJvb3QgfHwgJycpLmNvbmNhdChzb3VyY2UsIFwiICovXCIpO1xuICAgIH0pO1xuICAgIHJldHVybiBbY29udGVudF0uY29uY2F0KHNvdXJjZVVSTHMpLmNvbmNhdChbc291cmNlTWFwcGluZ10pLmpvaW4oJ1xcbicpO1xuICB9XG5cbiAgcmV0dXJuIFtjb250ZW50XS5qb2luKCdcXG4nKTtcbn0gLy8gQWRhcHRlZCBmcm9tIGNvbnZlcnQtc291cmNlLW1hcCAoTUlUKVxuXG5cbmZ1bmN0aW9uIHRvQ29tbWVudChzb3VyY2VNYXApIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVmXG4gIHZhciBiYXNlNjQgPSBidG9hKHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChKU09OLnN0cmluZ2lmeShzb3VyY2VNYXApKSkpO1xuICB2YXIgZGF0YSA9IFwic291cmNlTWFwcGluZ1VSTD1kYXRhOmFwcGxpY2F0aW9uL2pzb247Y2hhcnNldD11dGYtODtiYXNlNjQsXCIuY29uY2F0KGJhc2U2NCk7XG4gIHJldHVybiBcIi8qIyBcIi5jb25jYXQoZGF0YSwgXCIgKi9cIik7XG59Il0sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./node_modules/css-loader/dist/runtime/api.js\n");

/***/ }),

/***/ "./src/css/style.scss":
/*!****************************!*\
  !*** ./src/css/style.scss ***!
  \****************************/
/*! unknown exports (runtime-defined) */
/*! runtime requirements: module, __webpack_require__, module.id */
/*! CommonJS bailout: module.exports is used directly at 82:0-14 */
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("var api = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ \"./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js\");\n            var content = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!../../node_modules/sass-loader/dist/cjs.js!./style.scss */ \"./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/css/style.scss\");\n\n            content = content.__esModule ? content.default : content;\n\n            if (typeof content === 'string') {\n              content = [[module.id, content, '']];\n            }\n\nvar options = {};\n\noptions.insert = \"head\";\noptions.singleton = false;\n\nvar update = api(content, options);\n\n\nif (true) {\n  if (!content.locals || module.hot.invalidate) {\n    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {\n  if (!a && b || a && !b) {\n    return false;\n  }\n\n  var p;\n\n  for (p in a) {\n    if (isNamedExport && p === 'default') {\n      // eslint-disable-next-line no-continue\n      continue;\n    }\n\n    if (a[p] !== b[p]) {\n      return false;\n    }\n  }\n\n  for (p in b) {\n    if (isNamedExport && p === 'default') {\n      // eslint-disable-next-line no-continue\n      continue;\n    }\n\n    if (!a[p]) {\n      return false;\n    }\n  }\n\n  return true;\n};\n    var oldLocals = content.locals;\n\n    module.hot.accept(\n      /*! !!../../node_modules/css-loader/dist/cjs.js!../../node_modules/sass-loader/dist/cjs.js!./style.scss */ \"./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/css/style.scss\",\n      function () {\n        content = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!../../node_modules/sass-loader/dist/cjs.js!./style.scss */ \"./node_modules/css-loader/dist/cjs.js!./node_modules/sass-loader/dist/cjs.js!./src/css/style.scss\");\n\n              content = content.__esModule ? content.default : content;\n\n              if (typeof content === 'string') {\n                content = [[module.id, content, '']];\n              }\n\n              if (!isEqualLocals(oldLocals, content.locals)) {\n                module.hot.invalidate();\n\n                return;\n              }\n\n              oldLocals = content.locals;\n\n              update(content);\n      }\n    )\n  }\n\n  module.hot.dispose(function() {\n    update();\n  });\n}\n\nmodule.exports = content.locals || {};//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY3NzL3N0eWxlLnNjc3MuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yb2NrZXQtZ2FtZS8uL3NyYy9jc3Mvc3R5bGUuc2Nzcz8zZmYwIl0sInNvdXJjZXNDb250ZW50IjpbInZhciBhcGkgPSByZXF1aXJlKFwiIS4uLy4uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiKTtcbiAgICAgICAgICAgIHZhciBjb250ZW50ID0gcmVxdWlyZShcIiEhLi4vLi4vbm9kZV9tb2R1bGVzL2Nzcy1sb2FkZXIvZGlzdC9janMuanMhLi4vLi4vbm9kZV9tb2R1bGVzL3Nhc3MtbG9hZGVyL2Rpc3QvY2pzLmpzIS4vc3R5bGUuc2Nzc1wiKTtcblxuICAgICAgICAgICAgY29udGVudCA9IGNvbnRlbnQuX19lc01vZHVsZSA/IGNvbnRlbnQuZGVmYXVsdCA6IGNvbnRlbnQ7XG5cbiAgICAgICAgICAgIGlmICh0eXBlb2YgY29udGVudCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgY29udGVudCA9IFtbbW9kdWxlLmlkLCBjb250ZW50LCAnJ11dO1xuICAgICAgICAgICAgfVxuXG52YXIgb3B0aW9ucyA9IHt9O1xuXG5vcHRpb25zLmluc2VydCA9IFwiaGVhZFwiO1xub3B0aW9ucy5zaW5nbGV0b24gPSBmYWxzZTtcblxudmFyIHVwZGF0ZSA9IGFwaShjb250ZW50LCBvcHRpb25zKTtcblxuXG5pZiAobW9kdWxlLmhvdCkge1xuICBpZiAoIWNvbnRlbnQubG9jYWxzIHx8IG1vZHVsZS5ob3QuaW52YWxpZGF0ZSkge1xuICAgIHZhciBpc0VxdWFsTG9jYWxzID0gZnVuY3Rpb24gaXNFcXVhbExvY2FscyhhLCBiLCBpc05hbWVkRXhwb3J0KSB7XG4gIGlmICghYSAmJiBiIHx8IGEgJiYgIWIpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICB2YXIgcDtcblxuICBmb3IgKHAgaW4gYSkge1xuICAgIGlmIChpc05hbWVkRXhwb3J0ICYmIHAgPT09ICdkZWZhdWx0Jykge1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnRpbnVlXG4gICAgICBjb250aW51ZTtcbiAgICB9XG5cbiAgICBpZiAoYVtwXSAhPT0gYltwXSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIGZvciAocCBpbiBiKSB7XG4gICAgaWYgKGlzTmFtZWRFeHBvcnQgJiYgcCA9PT0gJ2RlZmF1bHQnKSB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29udGludWVcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGlmICghYVtwXSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiB0cnVlO1xufTtcbiAgICB2YXIgb2xkTG9jYWxzID0gY29udGVudC5sb2NhbHM7XG5cbiAgICBtb2R1bGUuaG90LmFjY2VwdChcbiAgICAgIFwiISEuLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvc2Fzcy1sb2FkZXIvZGlzdC9janMuanMhLi9zdHlsZS5zY3NzXCIsXG4gICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNvbnRlbnQgPSByZXF1aXJlKFwiISEuLi8uLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L2Nqcy5qcyEuLi8uLi9ub2RlX21vZHVsZXMvc2Fzcy1sb2FkZXIvZGlzdC9janMuanMhLi9zdHlsZS5zY3NzXCIpO1xuXG4gICAgICAgICAgICAgIGNvbnRlbnQgPSBjb250ZW50Ll9fZXNNb2R1bGUgPyBjb250ZW50LmRlZmF1bHQgOiBjb250ZW50O1xuXG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgY29udGVudCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICBjb250ZW50ID0gW1ttb2R1bGUuaWQsIGNvbnRlbnQsICcnXV07XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBpZiAoIWlzRXF1YWxMb2NhbHMob2xkTG9jYWxzLCBjb250ZW50LmxvY2FscykpIHtcbiAgICAgICAgICAgICAgICBtb2R1bGUuaG90LmludmFsaWRhdGUoKTtcblxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIG9sZExvY2FscyA9IGNvbnRlbnQubG9jYWxzO1xuXG4gICAgICAgICAgICAgIHVwZGF0ZShjb250ZW50KTtcbiAgICAgIH1cbiAgICApXG4gIH1cblxuICBtb2R1bGUuaG90LmRpc3Bvc2UoZnVuY3Rpb24oKSB7XG4gICAgdXBkYXRlKCk7XG4gIH0pO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNvbnRlbnQubG9jYWxzIHx8IHt9OyJdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/css/style.scss\n");

/***/ }),

/***/ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
/*!****************************************************************************!*\
  !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
  \****************************************************************************/
/*! unknown exports (runtime-defined) */
/*! runtime requirements: module, __webpack_require__.nc, __webpack_require__.* */
/*! CommonJS bailout: module.exports is used directly at 230:0-14 */
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
eval("\n\nvar isOldIE = function isOldIE() {\n  var memo;\n  return function memorize() {\n    if (typeof memo === 'undefined') {\n      // Test for IE <= 9 as proposed by Browserhacks\n      // @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805\n      // Tests for existence of standard globals is to allow style-loader\n      // to operate correctly into non-standard environments\n      // @see https://github.com/webpack-contrib/style-loader/issues/177\n      memo = Boolean(window && document && document.all && !window.atob);\n    }\n\n    return memo;\n  };\n}();\n\nvar getTarget = function getTarget() {\n  var memo = {};\n  return function memorize(target) {\n    if (typeof memo[target] === 'undefined') {\n      var styleTarget = document.querySelector(target); // Special case to return head of iframe instead of iframe itself\n\n      if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {\n        try {\n          // This will throw an exception if access to iframe is blocked\n          // due to cross-origin restrictions\n          styleTarget = styleTarget.contentDocument.head;\n        } catch (e) {\n          // istanbul ignore next\n          styleTarget = null;\n        }\n      }\n\n      memo[target] = styleTarget;\n    }\n\n    return memo[target];\n  };\n}();\n\nvar stylesInDom = [];\n\nfunction getIndexByIdentifier(identifier) {\n  var result = -1;\n\n  for (var i = 0; i < stylesInDom.length; i++) {\n    if (stylesInDom[i].identifier === identifier) {\n      result = i;\n      break;\n    }\n  }\n\n  return result;\n}\n\nfunction modulesToDom(list, options) {\n  var idCountMap = {};\n  var identifiers = [];\n\n  for (var i = 0; i < list.length; i++) {\n    var item = list[i];\n    var id = options.base ? item[0] + options.base : item[0];\n    var count = idCountMap[id] || 0;\n    var identifier = \"\".concat(id, \" \").concat(count);\n    idCountMap[id] = count + 1;\n    var index = getIndexByIdentifier(identifier);\n    var obj = {\n      css: item[1],\n      media: item[2],\n      sourceMap: item[3]\n    };\n\n    if (index !== -1) {\n      stylesInDom[index].references++;\n      stylesInDom[index].updater(obj);\n    } else {\n      stylesInDom.push({\n        identifier: identifier,\n        updater: addStyle(obj, options),\n        references: 1\n      });\n    }\n\n    identifiers.push(identifier);\n  }\n\n  return identifiers;\n}\n\nfunction insertStyleElement(options) {\n  var style = document.createElement('style');\n  var attributes = options.attributes || {};\n\n  if (typeof attributes.nonce === 'undefined') {\n    var nonce =  true ? __webpack_require__.nc : 0;\n\n    if (nonce) {\n      attributes.nonce = nonce;\n    }\n  }\n\n  Object.keys(attributes).forEach(function (key) {\n    style.setAttribute(key, attributes[key]);\n  });\n\n  if (typeof options.insert === 'function') {\n    options.insert(style);\n  } else {\n    var target = getTarget(options.insert || 'head');\n\n    if (!target) {\n      throw new Error(\"Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.\");\n    }\n\n    target.appendChild(style);\n  }\n\n  return style;\n}\n\nfunction removeStyleElement(style) {\n  // istanbul ignore if\n  if (style.parentNode === null) {\n    return false;\n  }\n\n  style.parentNode.removeChild(style);\n}\n/* istanbul ignore next  */\n\n\nvar replaceText = function replaceText() {\n  var textStore = [];\n  return function replace(index, replacement) {\n    textStore[index] = replacement;\n    return textStore.filter(Boolean).join('\\n');\n  };\n}();\n\nfunction applyToSingletonTag(style, index, remove, obj) {\n  var css = remove ? '' : obj.media ? \"@media \".concat(obj.media, \" {\").concat(obj.css, \"}\") : obj.css; // For old IE\n\n  /* istanbul ignore if  */\n\n  if (style.styleSheet) {\n    style.styleSheet.cssText = replaceText(index, css);\n  } else {\n    var cssNode = document.createTextNode(css);\n    var childNodes = style.childNodes;\n\n    if (childNodes[index]) {\n      style.removeChild(childNodes[index]);\n    }\n\n    if (childNodes.length) {\n      style.insertBefore(cssNode, childNodes[index]);\n    } else {\n      style.appendChild(cssNode);\n    }\n  }\n}\n\nfunction applyToTag(style, options, obj) {\n  var css = obj.css;\n  var media = obj.media;\n  var sourceMap = obj.sourceMap;\n\n  if (media) {\n    style.setAttribute('media', media);\n  } else {\n    style.removeAttribute('media');\n  }\n\n  if (sourceMap && typeof btoa !== 'undefined') {\n    css += \"\\n/*# sourceMappingURL=data:application/json;base64,\".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), \" */\");\n  } // For old IE\n\n  /* istanbul ignore if  */\n\n\n  if (style.styleSheet) {\n    style.styleSheet.cssText = css;\n  } else {\n    while (style.firstChild) {\n      style.removeChild(style.firstChild);\n    }\n\n    style.appendChild(document.createTextNode(css));\n  }\n}\n\nvar singleton = null;\nvar singletonCounter = 0;\n\nfunction addStyle(obj, options) {\n  var style;\n  var update;\n  var remove;\n\n  if (options.singleton) {\n    var styleIndex = singletonCounter++;\n    style = singleton || (singleton = insertStyleElement(options));\n    update = applyToSingletonTag.bind(null, style, styleIndex, false);\n    remove = applyToSingletonTag.bind(null, style, styleIndex, true);\n  } else {\n    style = insertStyleElement(options);\n    update = applyToTag.bind(null, style, options);\n\n    remove = function remove() {\n      removeStyleElement(style);\n    };\n  }\n\n  update(obj);\n  return function updateStyle(newObj) {\n    if (newObj) {\n      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap) {\n        return;\n      }\n\n      update(obj = newObj);\n    } else {\n      remove();\n    }\n  };\n}\n\nmodule.exports = function (list, options) {\n  options = options || {}; // Force single-tag solution on IE6-9, which has a hard limit on the # of <style>\n  // tags it will allow on a page\n\n  if (!options.singleton && typeof options.singleton !== 'boolean') {\n    options.singleton = isOldIE();\n  }\n\n  list = list || [];\n  var lastIdentifiers = modulesToDom(list, options);\n  return function update(newList) {\n    newList = newList || [];\n\n    if (Object.prototype.toString.call(newList) !== '[object Array]') {\n      return;\n    }\n\n    for (var i = 0; i < lastIdentifiers.length; i++) {\n      var identifier = lastIdentifiers[i];\n      var index = getIndexByIdentifier(identifier);\n      stylesInDom[index].references--;\n    }\n\n    var newLastIdentifiers = modulesToDom(newList, options);\n\n    for (var _i = 0; _i < lastIdentifiers.length; _i++) {\n      var _identifier = lastIdentifiers[_i];\n\n      var _index = getIndexByIdentifier(_identifier);\n\n      if (stylesInDom[_index].references === 0) {\n        stylesInDom[_index].updater();\n\n        stylesInDom.splice(_index, 1);\n      }\n    }\n\n    lastIdentifiers = newLastIdentifiers;\n  };\n};//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvc3R5bGUtbG9hZGVyL2Rpc3QvcnVudGltZS9pbmplY3RTdHlsZXNJbnRvU3R5bGVUYWcuanMuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yb2NrZXQtZ2FtZS8uL25vZGVfbW9kdWxlcy9zdHlsZS1sb2FkZXIvZGlzdC9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qcz8yZGJhIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xuXG52YXIgaXNPbGRJRSA9IGZ1bmN0aW9uIGlzT2xkSUUoKSB7XG4gIHZhciBtZW1vO1xuICByZXR1cm4gZnVuY3Rpb24gbWVtb3JpemUoKSB7XG4gICAgaWYgKHR5cGVvZiBtZW1vID09PSAndW5kZWZpbmVkJykge1xuICAgICAgLy8gVGVzdCBmb3IgSUUgPD0gOSBhcyBwcm9wb3NlZCBieSBCcm93c2VyaGFja3NcbiAgICAgIC8vIEBzZWUgaHR0cDovL2Jyb3dzZXJoYWNrcy5jb20vI2hhY2stZTcxZDg2OTJmNjUzMzQxNzNmZWU3MTVjMjIyY2I4MDVcbiAgICAgIC8vIFRlc3RzIGZvciBleGlzdGVuY2Ugb2Ygc3RhbmRhcmQgZ2xvYmFscyBpcyB0byBhbGxvdyBzdHlsZS1sb2FkZXJcbiAgICAgIC8vIHRvIG9wZXJhdGUgY29ycmVjdGx5IGludG8gbm9uLXN0YW5kYXJkIGVudmlyb25tZW50c1xuICAgICAgLy8gQHNlZSBodHRwczovL2dpdGh1Yi5jb20vd2VicGFjay1jb250cmliL3N0eWxlLWxvYWRlci9pc3N1ZXMvMTc3XG4gICAgICBtZW1vID0gQm9vbGVhbih3aW5kb3cgJiYgZG9jdW1lbnQgJiYgZG9jdW1lbnQuYWxsICYmICF3aW5kb3cuYXRvYik7XG4gICAgfVxuXG4gICAgcmV0dXJuIG1lbW87XG4gIH07XG59KCk7XG5cbnZhciBnZXRUYXJnZXQgPSBmdW5jdGlvbiBnZXRUYXJnZXQoKSB7XG4gIHZhciBtZW1vID0ge307XG4gIHJldHVybiBmdW5jdGlvbiBtZW1vcml6ZSh0YXJnZXQpIHtcbiAgICBpZiAodHlwZW9mIG1lbW9bdGFyZ2V0XSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHZhciBzdHlsZVRhcmdldCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IodGFyZ2V0KTsgLy8gU3BlY2lhbCBjYXNlIHRvIHJldHVybiBoZWFkIG9mIGlmcmFtZSBpbnN0ZWFkIG9mIGlmcmFtZSBpdHNlbGZcblxuICAgICAgaWYgKHdpbmRvdy5IVE1MSUZyYW1lRWxlbWVudCAmJiBzdHlsZVRhcmdldCBpbnN0YW5jZW9mIHdpbmRvdy5IVE1MSUZyYW1lRWxlbWVudCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIC8vIFRoaXMgd2lsbCB0aHJvdyBhbiBleGNlcHRpb24gaWYgYWNjZXNzIHRvIGlmcmFtZSBpcyBibG9ja2VkXG4gICAgICAgICAgLy8gZHVlIHRvIGNyb3NzLW9yaWdpbiByZXN0cmljdGlvbnNcbiAgICAgICAgICBzdHlsZVRhcmdldCA9IHN0eWxlVGFyZ2V0LmNvbnRlbnREb2N1bWVudC5oZWFkO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy8gaXN0YW5idWwgaWdub3JlIG5leHRcbiAgICAgICAgICBzdHlsZVRhcmdldCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbWVtb1t0YXJnZXRdID0gc3R5bGVUYXJnZXQ7XG4gICAgfVxuXG4gICAgcmV0dXJuIG1lbW9bdGFyZ2V0XTtcbiAgfTtcbn0oKTtcblxudmFyIHN0eWxlc0luRG9tID0gW107XG5cbmZ1bmN0aW9uIGdldEluZGV4QnlJZGVudGlmaWVyKGlkZW50aWZpZXIpIHtcbiAgdmFyIHJlc3VsdCA9IC0xO1xuXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgc3R5bGVzSW5Eb20ubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoc3R5bGVzSW5Eb21baV0uaWRlbnRpZmllciA9PT0gaWRlbnRpZmllcikge1xuICAgICAgcmVzdWx0ID0gaTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiByZXN1bHQ7XG59XG5cbmZ1bmN0aW9uIG1vZHVsZXNUb0RvbShsaXN0LCBvcHRpb25zKSB7XG4gIHZhciBpZENvdW50TWFwID0ge307XG4gIHZhciBpZGVudGlmaWVycyA9IFtdO1xuXG4gIGZvciAodmFyIGkgPSAwOyBpIDwgbGlzdC5sZW5ndGg7IGkrKykge1xuICAgIHZhciBpdGVtID0gbGlzdFtpXTtcbiAgICB2YXIgaWQgPSBvcHRpb25zLmJhc2UgPyBpdGVtWzBdICsgb3B0aW9ucy5iYXNlIDogaXRlbVswXTtcbiAgICB2YXIgY291bnQgPSBpZENvdW50TWFwW2lkXSB8fCAwO1xuICAgIHZhciBpZGVudGlmaWVyID0gXCJcIi5jb25jYXQoaWQsIFwiIFwiKS5jb25jYXQoY291bnQpO1xuICAgIGlkQ291bnRNYXBbaWRdID0gY291bnQgKyAxO1xuICAgIHZhciBpbmRleCA9IGdldEluZGV4QnlJZGVudGlmaWVyKGlkZW50aWZpZXIpO1xuICAgIHZhciBvYmogPSB7XG4gICAgICBjc3M6IGl0ZW1bMV0sXG4gICAgICBtZWRpYTogaXRlbVsyXSxcbiAgICAgIHNvdXJjZU1hcDogaXRlbVszXVxuICAgIH07XG5cbiAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICBzdHlsZXNJbkRvbVtpbmRleF0ucmVmZXJlbmNlcysrO1xuICAgICAgc3R5bGVzSW5Eb21baW5kZXhdLnVwZGF0ZXIob2JqKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc3R5bGVzSW5Eb20ucHVzaCh7XG4gICAgICAgIGlkZW50aWZpZXI6IGlkZW50aWZpZXIsXG4gICAgICAgIHVwZGF0ZXI6IGFkZFN0eWxlKG9iaiwgb3B0aW9ucyksXG4gICAgICAgIHJlZmVyZW5jZXM6IDFcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGlkZW50aWZpZXJzLnB1c2goaWRlbnRpZmllcik7XG4gIH1cblxuICByZXR1cm4gaWRlbnRpZmllcnM7XG59XG5cbmZ1bmN0aW9uIGluc2VydFN0eWxlRWxlbWVudChvcHRpb25zKSB7XG4gIHZhciBzdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7XG4gIHZhciBhdHRyaWJ1dGVzID0gb3B0aW9ucy5hdHRyaWJ1dGVzIHx8IHt9O1xuXG4gIGlmICh0eXBlb2YgYXR0cmlidXRlcy5ub25jZSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICB2YXIgbm9uY2UgPSB0eXBlb2YgX193ZWJwYWNrX25vbmNlX18gIT09ICd1bmRlZmluZWQnID8gX193ZWJwYWNrX25vbmNlX18gOiBudWxsO1xuXG4gICAgaWYgKG5vbmNlKSB7XG4gICAgICBhdHRyaWJ1dGVzLm5vbmNlID0gbm9uY2U7XG4gICAgfVxuICB9XG5cbiAgT2JqZWN0LmtleXMoYXR0cmlidXRlcykuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7XG4gICAgc3R5bGUuc2V0QXR0cmlidXRlKGtleSwgYXR0cmlidXRlc1trZXldKTtcbiAgfSk7XG5cbiAgaWYgKHR5cGVvZiBvcHRpb25zLmluc2VydCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIG9wdGlvbnMuaW5zZXJ0KHN0eWxlKTtcbiAgfSBlbHNlIHtcbiAgICB2YXIgdGFyZ2V0ID0gZ2V0VGFyZ2V0KG9wdGlvbnMuaW5zZXJ0IHx8ICdoZWFkJyk7XG5cbiAgICBpZiAoIXRhcmdldCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ291bGRuJ3QgZmluZCBhIHN0eWxlIHRhcmdldC4gVGhpcyBwcm9iYWJseSBtZWFucyB0aGF0IHRoZSB2YWx1ZSBmb3IgdGhlICdpbnNlcnQnIHBhcmFtZXRlciBpcyBpbnZhbGlkLlwiKTtcbiAgICB9XG5cbiAgICB0YXJnZXQuYXBwZW5kQ2hpbGQoc3R5bGUpO1xuICB9XG5cbiAgcmV0dXJuIHN0eWxlO1xufVxuXG5mdW5jdGlvbiByZW1vdmVTdHlsZUVsZW1lbnQoc3R5bGUpIHtcbiAgLy8gaXN0YW5idWwgaWdub3JlIGlmXG4gIGlmIChzdHlsZS5wYXJlbnROb2RlID09PSBudWxsKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgc3R5bGUucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzdHlsZSk7XG59XG4vKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAgKi9cblxuXG52YXIgcmVwbGFjZVRleHQgPSBmdW5jdGlvbiByZXBsYWNlVGV4dCgpIHtcbiAgdmFyIHRleHRTdG9yZSA9IFtdO1xuICByZXR1cm4gZnVuY3Rpb24gcmVwbGFjZShpbmRleCwgcmVwbGFjZW1lbnQpIHtcbiAgICB0ZXh0U3RvcmVbaW5kZXhdID0gcmVwbGFjZW1lbnQ7XG4gICAgcmV0dXJuIHRleHRTdG9yZS5maWx0ZXIoQm9vbGVhbikuam9pbignXFxuJyk7XG4gIH07XG59KCk7XG5cbmZ1bmN0aW9uIGFwcGx5VG9TaW5nbGV0b25UYWcoc3R5bGUsIGluZGV4LCByZW1vdmUsIG9iaikge1xuICB2YXIgY3NzID0gcmVtb3ZlID8gJycgOiBvYmoubWVkaWEgPyBcIkBtZWRpYSBcIi5jb25jYXQob2JqLm1lZGlhLCBcIiB7XCIpLmNvbmNhdChvYmouY3NzLCBcIn1cIikgOiBvYmouY3NzOyAvLyBGb3Igb2xkIElFXG5cbiAgLyogaXN0YW5idWwgaWdub3JlIGlmICAqL1xuXG4gIGlmIChzdHlsZS5zdHlsZVNoZWV0KSB7XG4gICAgc3R5bGUuc3R5bGVTaGVldC5jc3NUZXh0ID0gcmVwbGFjZVRleHQoaW5kZXgsIGNzcyk7XG4gIH0gZWxzZSB7XG4gICAgdmFyIGNzc05vZGUgPSBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjc3MpO1xuICAgIHZhciBjaGlsZE5vZGVzID0gc3R5bGUuY2hpbGROb2RlcztcblxuICAgIGlmIChjaGlsZE5vZGVzW2luZGV4XSkge1xuICAgICAgc3R5bGUucmVtb3ZlQ2hpbGQoY2hpbGROb2Rlc1tpbmRleF0pO1xuICAgIH1cblxuICAgIGlmIChjaGlsZE5vZGVzLmxlbmd0aCkge1xuICAgICAgc3R5bGUuaW5zZXJ0QmVmb3JlKGNzc05vZGUsIGNoaWxkTm9kZXNbaW5kZXhdKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc3R5bGUuYXBwZW5kQ2hpbGQoY3NzTm9kZSk7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIGFwcGx5VG9UYWcoc3R5bGUsIG9wdGlvbnMsIG9iaikge1xuICB2YXIgY3NzID0gb2JqLmNzcztcbiAgdmFyIG1lZGlhID0gb2JqLm1lZGlhO1xuICB2YXIgc291cmNlTWFwID0gb2JqLnNvdXJjZU1hcDtcblxuICBpZiAobWVkaWEpIHtcbiAgICBzdHlsZS5zZXRBdHRyaWJ1dGUoJ21lZGlhJywgbWVkaWEpO1xuICB9IGVsc2Uge1xuICAgIHN0eWxlLnJlbW92ZUF0dHJpYnV0ZSgnbWVkaWEnKTtcbiAgfVxuXG4gIGlmIChzb3VyY2VNYXAgJiYgdHlwZW9mIGJ0b2EgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgY3NzICs9IFwiXFxuLyojIHNvdXJjZU1hcHBpbmdVUkw9ZGF0YTphcHBsaWNhdGlvbi9qc29uO2Jhc2U2NCxcIi5jb25jYXQoYnRvYSh1bmVzY2FwZShlbmNvZGVVUklDb21wb25lbnQoSlNPTi5zdHJpbmdpZnkoc291cmNlTWFwKSkpKSwgXCIgKi9cIik7XG4gIH0gLy8gRm9yIG9sZCBJRVxuXG4gIC8qIGlzdGFuYnVsIGlnbm9yZSBpZiAgKi9cblxuXG4gIGlmIChzdHlsZS5zdHlsZVNoZWV0KSB7XG4gICAgc3R5bGUuc3R5bGVTaGVldC5jc3NUZXh0ID0gY3NzO1xuICB9IGVsc2Uge1xuICAgIHdoaWxlIChzdHlsZS5maXJzdENoaWxkKSB7XG4gICAgICBzdHlsZS5yZW1vdmVDaGlsZChzdHlsZS5maXJzdENoaWxkKTtcbiAgICB9XG5cbiAgICBzdHlsZS5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjc3MpKTtcbiAgfVxufVxuXG52YXIgc2luZ2xldG9uID0gbnVsbDtcbnZhciBzaW5nbGV0b25Db3VudGVyID0gMDtcblxuZnVuY3Rpb24gYWRkU3R5bGUob2JqLCBvcHRpb25zKSB7XG4gIHZhciBzdHlsZTtcbiAgdmFyIHVwZGF0ZTtcbiAgdmFyIHJlbW92ZTtcblxuICBpZiAob3B0aW9ucy5zaW5nbGV0b24pIHtcbiAgICB2YXIgc3R5bGVJbmRleCA9IHNpbmdsZXRvbkNvdW50ZXIrKztcbiAgICBzdHlsZSA9IHNpbmdsZXRvbiB8fCAoc2luZ2xldG9uID0gaW5zZXJ0U3R5bGVFbGVtZW50KG9wdGlvbnMpKTtcbiAgICB1cGRhdGUgPSBhcHBseVRvU2luZ2xldG9uVGFnLmJpbmQobnVsbCwgc3R5bGUsIHN0eWxlSW5kZXgsIGZhbHNlKTtcbiAgICByZW1vdmUgPSBhcHBseVRvU2luZ2xldG9uVGFnLmJpbmQobnVsbCwgc3R5bGUsIHN0eWxlSW5kZXgsIHRydWUpO1xuICB9IGVsc2Uge1xuICAgIHN0eWxlID0gaW5zZXJ0U3R5bGVFbGVtZW50KG9wdGlvbnMpO1xuICAgIHVwZGF0ZSA9IGFwcGx5VG9UYWcuYmluZChudWxsLCBzdHlsZSwgb3B0aW9ucyk7XG5cbiAgICByZW1vdmUgPSBmdW5jdGlvbiByZW1vdmUoKSB7XG4gICAgICByZW1vdmVTdHlsZUVsZW1lbnQoc3R5bGUpO1xuICAgIH07XG4gIH1cblxuICB1cGRhdGUob2JqKTtcbiAgcmV0dXJuIGZ1bmN0aW9uIHVwZGF0ZVN0eWxlKG5ld09iaikge1xuICAgIGlmIChuZXdPYmopIHtcbiAgICAgIGlmIChuZXdPYmouY3NzID09PSBvYmouY3NzICYmIG5ld09iai5tZWRpYSA9PT0gb2JqLm1lZGlhICYmIG5ld09iai5zb3VyY2VNYXAgPT09IG9iai5zb3VyY2VNYXApIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICB1cGRhdGUob2JqID0gbmV3T2JqKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVtb3ZlKCk7XG4gICAgfVxuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChsaXN0LCBvcHRpb25zKSB7XG4gIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9OyAvLyBGb3JjZSBzaW5nbGUtdGFnIHNvbHV0aW9uIG9uIElFNi05LCB3aGljaCBoYXMgYSBoYXJkIGxpbWl0IG9uIHRoZSAjIG9mIDxzdHlsZT5cbiAgLy8gdGFncyBpdCB3aWxsIGFsbG93IG9uIGEgcGFnZVxuXG4gIGlmICghb3B0aW9ucy5zaW5nbGV0b24gJiYgdHlwZW9mIG9wdGlvbnMuc2luZ2xldG9uICE9PSAnYm9vbGVhbicpIHtcbiAgICBvcHRpb25zLnNpbmdsZXRvbiA9IGlzT2xkSUUoKTtcbiAgfVxuXG4gIGxpc3QgPSBsaXN0IHx8IFtdO1xuICB2YXIgbGFzdElkZW50aWZpZXJzID0gbW9kdWxlc1RvRG9tKGxpc3QsIG9wdGlvbnMpO1xuICByZXR1cm4gZnVuY3Rpb24gdXBkYXRlKG5ld0xpc3QpIHtcbiAgICBuZXdMaXN0ID0gbmV3TGlzdCB8fCBbXTtcblxuICAgIGlmIChPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwobmV3TGlzdCkgIT09ICdbb2JqZWN0IEFycmF5XScpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxhc3RJZGVudGlmaWVycy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIGlkZW50aWZpZXIgPSBsYXN0SWRlbnRpZmllcnNbaV07XG4gICAgICB2YXIgaW5kZXggPSBnZXRJbmRleEJ5SWRlbnRpZmllcihpZGVudGlmaWVyKTtcbiAgICAgIHN0eWxlc0luRG9tW2luZGV4XS5yZWZlcmVuY2VzLS07XG4gICAgfVxuXG4gICAgdmFyIG5ld0xhc3RJZGVudGlmaWVycyA9IG1vZHVsZXNUb0RvbShuZXdMaXN0LCBvcHRpb25zKTtcblxuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBsYXN0SWRlbnRpZmllcnMubGVuZ3RoOyBfaSsrKSB7XG4gICAgICB2YXIgX2lkZW50aWZpZXIgPSBsYXN0SWRlbnRpZmllcnNbX2ldO1xuXG4gICAgICB2YXIgX2luZGV4ID0gZ2V0SW5kZXhCeUlkZW50aWZpZXIoX2lkZW50aWZpZXIpO1xuXG4gICAgICBpZiAoc3R5bGVzSW5Eb21bX2luZGV4XS5yZWZlcmVuY2VzID09PSAwKSB7XG4gICAgICAgIHN0eWxlc0luRG9tW19pbmRleF0udXBkYXRlcigpO1xuXG4gICAgICAgIHN0eWxlc0luRG9tLnNwbGljZShfaW5kZXgsIDEpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGxhc3RJZGVudGlmaWVycyA9IG5ld0xhc3RJZGVudGlmaWVycztcbiAgfTtcbn07Il0sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js\n");

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! namespace exports */
/*! exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__, __webpack_require__.n, __webpack_require__.r, __webpack_exports__, module, __webpack_require__.* */
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _css_style_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./css/style.scss */ \"./src/css/style.scss\");\n/* harmony import */ var _css_style_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_css_style_scss__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./js */ \"./src/js/index.js\");\n/**\n * File for setting up the environment. Please do not modify.\n */\n\n\n\n\nif (true) {\n    module.hot.accept();\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvaW5kZXguanMuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yb2NrZXQtZ2FtZS8uL3NyYy9pbmRleC5qcz9iNjM1Il0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogRmlsZSBmb3Igc2V0dGluZyB1cCB0aGUgZW52aXJvbm1lbnQuIFBsZWFzZSBkbyBub3QgbW9kaWZ5LlxuICovXG5cbmltcG9ydCBcIi4vY3NzL3N0eWxlLnNjc3NcIlxuaW1wb3J0IFwiLi9qc1wiXG5cbmlmIChtb2R1bGUuaG90KSB7XG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOyIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/index.js\n");

/***/ }),

/***/ "./src/js/components/asteroid.js":
/*!***************************************!*\
  !*** ./src/js/components/asteroid.js ***!
  \***************************************/
/*! namespace exports */
/*! export default [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__.r, __webpack_exports__, __webpack_require__.d, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => /* binding */ Asteroid\n/* harmony export */ });\nclass Asteroid {\n  constructor(x, y, radius, color) {\n    this.x = x;\n    this.y = y;\n    this.radius = radius;\n    this.width = radius * 2;\n    this.height = radius * 2;\n    this.color = color;\n  }\n  draw(context, xView, yView) {\n    context.beginPath();\n    context.arc(this.x - xView, this.y - yView, this.radius, 0, 2 * Math.PI, false);\n    context.fillStyle = this.color;\n    context.fill();\n  }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvanMvY29tcG9uZW50cy9hc3Rlcm9pZC5qcy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovL3JvY2tldC1nYW1lLy4vc3JjL2pzL2NvbXBvbmVudHMvYXN0ZXJvaWQuanM/MzA1NyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBjbGFzcyBBc3Rlcm9pZCB7XG4gIGNvbnN0cnVjdG9yKHgsIHksIHJhZGl1cywgY29sb3IpIHtcbiAgICB0aGlzLnggPSB4O1xuICAgIHRoaXMueSA9IHk7XG4gICAgdGhpcy5yYWRpdXMgPSByYWRpdXM7XG4gICAgdGhpcy53aWR0aCA9IHJhZGl1cyAqIDI7XG4gICAgdGhpcy5oZWlnaHQgPSByYWRpdXMgKiAyO1xuICAgIHRoaXMuY29sb3IgPSBjb2xvcjtcbiAgfVxuICBkcmF3KGNvbnRleHQsIHhWaWV3LCB5Vmlldykge1xuICAgIGNvbnRleHQuYmVnaW5QYXRoKCk7XG4gICAgY29udGV4dC5hcmModGhpcy54IC0geFZpZXcsIHRoaXMueSAtIHlWaWV3LCB0aGlzLnJhZGl1cywgMCwgMiAqIE1hdGguUEksIGZhbHNlKTtcbiAgICBjb250ZXh0LmZpbGxTdHlsZSA9IHRoaXMuY29sb3I7XG4gICAgY29udGV4dC5maWxsKCk7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOyIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/js/components/asteroid.js\n");

/***/ }),

/***/ "./src/js/components/camera/constants/index.js":
/*!*****************************************************!*\
  !*** ./src/js/components/camera/constants/index.js ***!
  \*****************************************************/
/*! namespace exports */
/*! export AXIS [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__.r, __webpack_exports__, __webpack_require__.d, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"AXIS\": () => /* binding */ AXIS\n/* harmony export */ });\nconst AXIS = {\n  NONE: 1,\n  HORIZONTAL: 2,\n  VERTICAL: 3,\n  BOTH: 4\n};//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvanMvY29tcG9uZW50cy9jYW1lcmEvY29uc3RhbnRzL2luZGV4LmpzLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcm9ja2V0LWdhbWUvLi9zcmMvanMvY29tcG9uZW50cy9jYW1lcmEvY29uc3RhbnRzL2luZGV4LmpzP2MyMTMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IEFYSVMgPSB7XG4gIE5PTkU6IDEsXG4gIEhPUklaT05UQUw6IDIsXG4gIFZFUlRJQ0FMOiAzLFxuICBCT1RIOiA0XG59OyJdLCJtYXBwaW5ncyI6Ijs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/js/components/camera/constants/index.js\n");

/***/ }),

/***/ "./src/js/components/camera/index.js":
/*!*******************************************!*\
  !*** ./src/js/components/camera/index.js ***!
  \*******************************************/
/*! namespace exports */
/*! export default [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__, __webpack_require__.r, __webpack_exports__, __webpack_require__.d, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => /* binding */ Camera\n/* harmony export */ });\n/* harmony import */ var _rectangle_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rectangle.js */ \"./src/js/components/camera/rectangle.js\");\n/* harmony import */ var _constants_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants/index.js */ \"./src/js/components/camera/constants/index.js\");\n\n\n\nclass Camera {\n  constructor(xView, yView, viewportWidth, viewportHeight, worldWidth, worldHeight) {\n    // position of camera (left-top coordinate)\n    this.xView = xView || 0;\n    this.yView = yView || 0;\n\n    // distance from followed object to border before camera starts move\n    this.xDeadZone = 0; // min distance to horizontal borders\n    this.yDeadZone = 0; // min distance to vertical borders\n\n    // viewport dimensions\n    this.wView = viewportWidth;\n    this.hView = viewportHeight;\n\n    // allow camera to move in vertical and horizontal axis\n    this.axis = _constants_index_js__WEBPACK_IMPORTED_MODULE_1__.AXIS.BOTH;\n\n    // object that should be followed\n    this.followed = null;\n\n    // rectangle that represents the viewport\n    this.viewportRect = new _rectangle_js__WEBPACK_IMPORTED_MODULE_0__.default(this.xView, this.yView, this.wView, this.hView);\n\n    // rectangle that represents the world's boundary (room's boundary)\n    this.worldRect = new _rectangle_js__WEBPACK_IMPORTED_MODULE_0__.default(0, 0, worldWidth, worldHeight);\n  }\n\n  // gameObject needs to have \"x\" and \"y\" properties (as world(or room) position)\n  follow(gameObject, xDeadZone, yDeadZone) {\n    this.followed = gameObject;\n    this.xDeadZone = xDeadZone;\n    this.yDeadZone = yDeadZone;\n  }\n\n  update() {\n    // keep following the player (or other desired object)\n    if (this.followed != null) {\n      if (this.axis == _constants_index_js__WEBPACK_IMPORTED_MODULE_1__.AXIS.HORIZONTAL || this.axis == _constants_index_js__WEBPACK_IMPORTED_MODULE_1__.AXIS.BOTH) {\n        // moves camera on horizontal axis based on followed object position\n        if (this.followed.x - this.xView + this.xDeadZone > this.wView)\n          this.xView = this.followed.x - (this.wView - this.xDeadZone);\n        else if (this.followed.x - this.xDeadZone < this.xView)\n          this.xView = this.followed.x - this.xDeadZone;\n      }\n      if (this.axis == _constants_index_js__WEBPACK_IMPORTED_MODULE_1__.AXIS.VERTICAL || this.axis == _constants_index_js__WEBPACK_IMPORTED_MODULE_1__.AXIS.BOTH) {\n        // moves camera on vertical axis based on followed object position\n        if (this.followed.y - this.yView + this.yDeadZone > this.hView)\n          this.yView = this.followed.y - (this.hView - this.yDeadZone);\n        else if (this.followed.y - this.yDeadZone < this.yView)\n          this.yView = this.followed.y - this.yDeadZone;\n      }\n\n    }\n\n    //   // update viewportRect\n    this.viewportRect.set(this.xView, this.yView);\n\n    //   // don't let camera leaves the world's boundary\n    if (!this.viewportRect.within(this.worldRect)) {\n      if (this.viewportRect.left < this.worldRect.left)\n        this.xView = this.worldRect.left;\n      if (this.viewportRect.top < this.worldRect.top)\n        this.yView = this.worldRect.top;\n      if (this.viewportRect.right > this.worldRect.right)\n        this.xView = this.worldRect.right - this.wView;\n      if (this.viewportRect.bottom > this.worldRect.bottom)\n        this.yView = this.worldRect.bottom - this.hView;\n    }\n\n  }\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvanMvY29tcG9uZW50cy9jYW1lcmEvaW5kZXguanMuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yb2NrZXQtZ2FtZS8uL3NyYy9qcy9jb21wb25lbnRzL2NhbWVyYS9pbmRleC5qcz9lNTRkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWN0YW5nbGUgZnJvbSAnLi9yZWN0YW5nbGUuanMnO1xuaW1wb3J0IHsgQVhJUyB9IGZyb20gJy4vY29uc3RhbnRzL2luZGV4LmpzJztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ2FtZXJhIHtcbiAgY29uc3RydWN0b3IoeFZpZXcsIHlWaWV3LCB2aWV3cG9ydFdpZHRoLCB2aWV3cG9ydEhlaWdodCwgd29ybGRXaWR0aCwgd29ybGRIZWlnaHQpIHtcbiAgICAvLyBwb3NpdGlvbiBvZiBjYW1lcmEgKGxlZnQtdG9wIGNvb3JkaW5hdGUpXG4gICAgdGhpcy54VmlldyA9IHhWaWV3IHx8IDA7XG4gICAgdGhpcy55VmlldyA9IHlWaWV3IHx8IDA7XG5cbiAgICAvLyBkaXN0YW5jZSBmcm9tIGZvbGxvd2VkIG9iamVjdCB0byBib3JkZXIgYmVmb3JlIGNhbWVyYSBzdGFydHMgbW92ZVxuICAgIHRoaXMueERlYWRab25lID0gMDsgLy8gbWluIGRpc3RhbmNlIHRvIGhvcml6b250YWwgYm9yZGVyc1xuICAgIHRoaXMueURlYWRab25lID0gMDsgLy8gbWluIGRpc3RhbmNlIHRvIHZlcnRpY2FsIGJvcmRlcnNcblxuICAgIC8vIHZpZXdwb3J0IGRpbWVuc2lvbnNcbiAgICB0aGlzLndWaWV3ID0gdmlld3BvcnRXaWR0aDtcbiAgICB0aGlzLmhWaWV3ID0gdmlld3BvcnRIZWlnaHQ7XG5cbiAgICAvLyBhbGxvdyBjYW1lcmEgdG8gbW92ZSBpbiB2ZXJ0aWNhbCBhbmQgaG9yaXpvbnRhbCBheGlzXG4gICAgdGhpcy5heGlzID0gQVhJUy5CT1RIO1xuXG4gICAgLy8gb2JqZWN0IHRoYXQgc2hvdWxkIGJlIGZvbGxvd2VkXG4gICAgdGhpcy5mb2xsb3dlZCA9IG51bGw7XG5cbiAgICAvLyByZWN0YW5nbGUgdGhhdCByZXByZXNlbnRzIHRoZSB2aWV3cG9ydFxuICAgIHRoaXMudmlld3BvcnRSZWN0ID0gbmV3IFJlY3RhbmdsZSh0aGlzLnhWaWV3LCB0aGlzLnlWaWV3LCB0aGlzLndWaWV3LCB0aGlzLmhWaWV3KTtcblxuICAgIC8vIHJlY3RhbmdsZSB0aGF0IHJlcHJlc2VudHMgdGhlIHdvcmxkJ3MgYm91bmRhcnkgKHJvb20ncyBib3VuZGFyeSlcbiAgICB0aGlzLndvcmxkUmVjdCA9IG5ldyBSZWN0YW5nbGUoMCwgMCwgd29ybGRXaWR0aCwgd29ybGRIZWlnaHQpO1xuICB9XG5cbiAgLy8gZ2FtZU9iamVjdCBuZWVkcyB0byBoYXZlIFwieFwiIGFuZCBcInlcIiBwcm9wZXJ0aWVzIChhcyB3b3JsZChvciByb29tKSBwb3NpdGlvbilcbiAgZm9sbG93KGdhbWVPYmplY3QsIHhEZWFkWm9uZSwgeURlYWRab25lKSB7XG4gICAgdGhpcy5mb2xsb3dlZCA9IGdhbWVPYmplY3Q7XG4gICAgdGhpcy54RGVhZFpvbmUgPSB4RGVhZFpvbmU7XG4gICAgdGhpcy55RGVhZFpvbmUgPSB5RGVhZFpvbmU7XG4gIH1cblxuICB1cGRhdGUoKSB7XG4gICAgLy8ga2VlcCBmb2xsb3dpbmcgdGhlIHBsYXllciAob3Igb3RoZXIgZGVzaXJlZCBvYmplY3QpXG4gICAgaWYgKHRoaXMuZm9sbG93ZWQgIT0gbnVsbCkge1xuICAgICAgaWYgKHRoaXMuYXhpcyA9PSBBWElTLkhPUklaT05UQUwgfHwgdGhpcy5heGlzID09IEFYSVMuQk9USCkge1xuICAgICAgICAvLyBtb3ZlcyBjYW1lcmEgb24gaG9yaXpvbnRhbCBheGlzIGJhc2VkIG9uIGZvbGxvd2VkIG9iamVjdCBwb3NpdGlvblxuICAgICAgICBpZiAodGhpcy5mb2xsb3dlZC54IC0gdGhpcy54VmlldyArIHRoaXMueERlYWRab25lID4gdGhpcy53VmlldylcbiAgICAgICAgICB0aGlzLnhWaWV3ID0gdGhpcy5mb2xsb3dlZC54IC0gKHRoaXMud1ZpZXcgLSB0aGlzLnhEZWFkWm9uZSk7XG4gICAgICAgIGVsc2UgaWYgKHRoaXMuZm9sbG93ZWQueCAtIHRoaXMueERlYWRab25lIDwgdGhpcy54VmlldylcbiAgICAgICAgICB0aGlzLnhWaWV3ID0gdGhpcy5mb2xsb3dlZC54IC0gdGhpcy54RGVhZFpvbmU7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5heGlzID09IEFYSVMuVkVSVElDQUwgfHwgdGhpcy5heGlzID09IEFYSVMuQk9USCkge1xuICAgICAgICAvLyBtb3ZlcyBjYW1lcmEgb24gdmVydGljYWwgYXhpcyBiYXNlZCBvbiBmb2xsb3dlZCBvYmplY3QgcG9zaXRpb25cbiAgICAgICAgaWYgKHRoaXMuZm9sbG93ZWQueSAtIHRoaXMueVZpZXcgKyB0aGlzLnlEZWFkWm9uZSA+IHRoaXMuaFZpZXcpXG4gICAgICAgICAgdGhpcy55VmlldyA9IHRoaXMuZm9sbG93ZWQueSAtICh0aGlzLmhWaWV3IC0gdGhpcy55RGVhZFpvbmUpO1xuICAgICAgICBlbHNlIGlmICh0aGlzLmZvbGxvd2VkLnkgLSB0aGlzLnlEZWFkWm9uZSA8IHRoaXMueVZpZXcpXG4gICAgICAgICAgdGhpcy55VmlldyA9IHRoaXMuZm9sbG93ZWQueSAtIHRoaXMueURlYWRab25lO1xuICAgICAgfVxuXG4gICAgfVxuXG4gICAgLy8gICAvLyB1cGRhdGUgdmlld3BvcnRSZWN0XG4gICAgdGhpcy52aWV3cG9ydFJlY3Quc2V0KHRoaXMueFZpZXcsIHRoaXMueVZpZXcpO1xuXG4gICAgLy8gICAvLyBkb24ndCBsZXQgY2FtZXJhIGxlYXZlcyB0aGUgd29ybGQncyBib3VuZGFyeVxuICAgIGlmICghdGhpcy52aWV3cG9ydFJlY3Qud2l0aGluKHRoaXMud29ybGRSZWN0KSkge1xuICAgICAgaWYgKHRoaXMudmlld3BvcnRSZWN0LmxlZnQgPCB0aGlzLndvcmxkUmVjdC5sZWZ0KVxuICAgICAgICB0aGlzLnhWaWV3ID0gdGhpcy53b3JsZFJlY3QubGVmdDtcbiAgICAgIGlmICh0aGlzLnZpZXdwb3J0UmVjdC50b3AgPCB0aGlzLndvcmxkUmVjdC50b3ApXG4gICAgICAgIHRoaXMueVZpZXcgPSB0aGlzLndvcmxkUmVjdC50b3A7XG4gICAgICBpZiAodGhpcy52aWV3cG9ydFJlY3QucmlnaHQgPiB0aGlzLndvcmxkUmVjdC5yaWdodClcbiAgICAgICAgdGhpcy54VmlldyA9IHRoaXMud29ybGRSZWN0LnJpZ2h0IC0gdGhpcy53VmlldztcbiAgICAgIGlmICh0aGlzLnZpZXdwb3J0UmVjdC5ib3R0b20gPiB0aGlzLndvcmxkUmVjdC5ib3R0b20pXG4gICAgICAgIHRoaXMueVZpZXcgPSB0aGlzLndvcmxkUmVjdC5ib3R0b20gLSB0aGlzLmhWaWV3O1xuICAgIH1cblxuICB9XG59Il0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/js/components/camera/index.js\n");

/***/ }),

/***/ "./src/js/components/camera/rectangle.js":
/*!***********************************************!*\
  !*** ./src/js/components/camera/rectangle.js ***!
  \***********************************************/
/*! namespace exports */
/*! export default [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__.r, __webpack_exports__, __webpack_require__.d, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => /* binding */ Rectangle\n/* harmony export */ });\nclass Rectangle {\n  constructor(left, top, width, height) {\n    this.left = left || 0;\n    this.top = top || 0;\n    this.width = width || 0;\n    this.height = height || 0;\n    this.right = this.left + this.width;\n    this.bottom = this.top + this.height;\n  }\n\n  set(left, top, width, height) {\n    this.left = left;\n    this.top = top;\n    this.width = width || this.width;\n    this.height = height || this.height\n    this.right = (this.left + this.width);\n    this.bottom = (this.top + this.height);\n  }\n\n  within(r) {\n    return (r.left <= this.left &&\n      r.right >= this.right &&\n      r.top <= this.top &&\n      r.bottom >= this.bottom);\n  }\n\n  overlaps(r) {\n    return (this.left < r.right &&\n      r.left < this.right &&\n      this.top < r.bottom &&\n      r.top < this.bottom);\n  }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvanMvY29tcG9uZW50cy9jYW1lcmEvcmVjdGFuZ2xlLmpzLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcm9ja2V0LWdhbWUvLi9zcmMvanMvY29tcG9uZW50cy9jYW1lcmEvcmVjdGFuZ2xlLmpzPzFmOWQiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVjdGFuZ2xlIHtcbiAgY29uc3RydWN0b3IobGVmdCwgdG9wLCB3aWR0aCwgaGVpZ2h0KSB7XG4gICAgdGhpcy5sZWZ0ID0gbGVmdCB8fCAwO1xuICAgIHRoaXMudG9wID0gdG9wIHx8IDA7XG4gICAgdGhpcy53aWR0aCA9IHdpZHRoIHx8IDA7XG4gICAgdGhpcy5oZWlnaHQgPSBoZWlnaHQgfHwgMDtcbiAgICB0aGlzLnJpZ2h0ID0gdGhpcy5sZWZ0ICsgdGhpcy53aWR0aDtcbiAgICB0aGlzLmJvdHRvbSA9IHRoaXMudG9wICsgdGhpcy5oZWlnaHQ7XG4gIH1cblxuICBzZXQobGVmdCwgdG9wLCB3aWR0aCwgaGVpZ2h0KSB7XG4gICAgdGhpcy5sZWZ0ID0gbGVmdDtcbiAgICB0aGlzLnRvcCA9IHRvcDtcbiAgICB0aGlzLndpZHRoID0gd2lkdGggfHwgdGhpcy53aWR0aDtcbiAgICB0aGlzLmhlaWdodCA9IGhlaWdodCB8fCB0aGlzLmhlaWdodFxuICAgIHRoaXMucmlnaHQgPSAodGhpcy5sZWZ0ICsgdGhpcy53aWR0aCk7XG4gICAgdGhpcy5ib3R0b20gPSAodGhpcy50b3AgKyB0aGlzLmhlaWdodCk7XG4gIH1cblxuICB3aXRoaW4ocikge1xuICAgIHJldHVybiAoci5sZWZ0IDw9IHRoaXMubGVmdCAmJlxuICAgICAgci5yaWdodCA+PSB0aGlzLnJpZ2h0ICYmXG4gICAgICByLnRvcCA8PSB0aGlzLnRvcCAmJlxuICAgICAgci5ib3R0b20gPj0gdGhpcy5ib3R0b20pO1xuICB9XG5cbiAgb3ZlcmxhcHMocikge1xuICAgIHJldHVybiAodGhpcy5sZWZ0IDwgci5yaWdodCAmJlxuICAgICAgci5sZWZ0IDwgdGhpcy5yaWdodCAmJlxuICAgICAgdGhpcy50b3AgPCByLmJvdHRvbSAmJlxuICAgICAgci50b3AgPCB0aGlzLmJvdHRvbSk7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTsiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/js/components/camera/rectangle.js\n");

/***/ }),

/***/ "./src/js/components/drag.js":
/*!***********************************!*\
  !*** ./src/js/components/drag.js ***!
  \***********************************/
/*! namespace exports */
/*! export default [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__.r, __webpack_exports__, __webpack_require__.d, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => /* binding */ Drag\n/* harmony export */ });\nclass Drag {\n  draw(context, x, y, mouse) {\n    if (mouse.isDown) {\n      context.beginPath();\n      context.moveTo(x, y);\n      context.lineWidth = 1;\n      context.lineTo(mouse.x, mouse.y);\n      context.strokeStyle = \"#fff\";\n      context.stroke();\n      context.closePath();\n    }\n  }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvanMvY29tcG9uZW50cy9kcmFnLmpzLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcm9ja2V0LWdhbWUvLi9zcmMvanMvY29tcG9uZW50cy9kcmFnLmpzPzBlZGMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgY2xhc3MgRHJhZyB7XG4gIGRyYXcoY29udGV4dCwgeCwgeSwgbW91c2UpIHtcbiAgICBpZiAobW91c2UuaXNEb3duKSB7XG4gICAgICBjb250ZXh0LmJlZ2luUGF0aCgpO1xuICAgICAgY29udGV4dC5tb3ZlVG8oeCwgeSk7XG4gICAgICBjb250ZXh0LmxpbmVXaWR0aCA9IDE7XG4gICAgICBjb250ZXh0LmxpbmVUbyhtb3VzZS54LCBtb3VzZS55KTtcbiAgICAgIGNvbnRleHQuc3Ryb2tlU3R5bGUgPSBcIiNmZmZcIjtcbiAgICAgIGNvbnRleHQuc3Ryb2tlKCk7XG4gICAgICBjb250ZXh0LmNsb3NlUGF0aCgpO1xuICAgIH1cbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Iiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/js/components/drag.js\n");

/***/ }),

/***/ "./src/js/components/player.js":
/*!*************************************!*\
  !*** ./src/js/components/player.js ***!
  \*************************************/
/*! namespace exports */
/*! export default [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__.r, __webpack_exports__, __webpack_require__.d, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => /* binding */ Player\n/* harmony export */ });\nclass Player {\n  constructor(x, y, radius, mass) {\n    this.x = x;\n    this.y = y;\n    this.prevY = y;\n    this.prevX = x;\n    this.angle = 0;\n    this.velocity = { x: 10, y: 0 };\n    this.mass = mass;\n    this.radius = radius; // 1px = 1cm\n    this.restitution = -0.8;\n    this.Cd = 0.47;  // Dimensionless\n    this.rho = 0.4; // kg / m^3\n    this.A = Math.PI * this.radius * this.radius / (10000); // m^2\n    this.ag = 9.81;  // m / s^2\n    this.width = radius * 2;\n    this.height = radius * 2;\n  }\n\n  update({ frameRate, worldWidth, worldHeight, mouse, canvas }) {\n    this.prevY = this.y;\n    this.prevX = this.x;\n\n    if (!mouse.isDown) {\n      // Do physics\n      // Drag force: Fd = -1/2 * Cd * A * rho * v * v\n      let Fx = -0.5 * this.Cd * this.A * this.rho * this.velocity.x * this.velocity.x * this.velocity.x / Math.abs(this.velocity.x);\n      let Fy = -0.5 * this.Cd * this.A * this.rho * this.velocity.y * this.velocity.y * this.velocity.y / Math.abs(this.velocity.y);\n\n      Fx = (isNaN(Fx) ? 0 : Fx);\n      Fy = (isNaN(Fy) ? 0 : Fy);\n\n      // Calculate acceleration ( F = ma )\n      const ax = Fx / this.mass;\n      const ay = this.ag + (Fy / this.mass);\n      // Integrate to get velocity\n      this.velocity.x += ax * frameRate;\n      this.velocity.y += ay * frameRate;\n\n      // Integrate to get position\n      this.x += this.velocity.x * frameRate * 100;\n      this.y += this.velocity.y * frameRate * 100;\n    }\n\n    // don't let player leaves the world's boundary\n    if (this.x - this.width / 2 < 0) {\n      this.velocity.x *= this.restitution;\n      this.x = this.width;\n    }\n    if (this.y - this.height / 2 < 0) {\n      this.velocity.y *= this.restitution;\n      this.y = this.height;\n    }\n    if (this.x + this.width / 2 > worldWidth) {\n      this.velocity.x *= this.restitution;\n      this.x = worldWidth - this.width / 2 - this.radius;\n    }\n    if (this.y + this.height / 2 > worldHeight) {\n      this.velocity.y *= this.restitution;\n      this.y = canvas.height - this.radius;\n    }\n    if (mouse.isDown) {\n      this.angle = Math.atan2(this.y - mouse.y, this.x - mouse.x);\n\n    } else {\n      this.angle = Math.atan2(this.y - this.prevY, this.x - this.prevX);\n    }\n  }\n\n  draw({ context, xView, yView, playerImg }) {\n    context.setTransform(1, 0, 0, 1, this.x - xView, this.y - yView);\n    context.rotate(this.angle);\n    context.drawImage(playerImg, -this.radius, -this.radius, this.width, this.height);\n  }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvanMvY29tcG9uZW50cy9wbGF5ZXIuanMuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yb2NrZXQtZ2FtZS8uL3NyYy9qcy9jb21wb25lbnRzL3BsYXllci5qcz8yZGQxIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGNsYXNzIFBsYXllciB7XG4gIGNvbnN0cnVjdG9yKHgsIHksIHJhZGl1cywgbWFzcykge1xuICAgIHRoaXMueCA9IHg7XG4gICAgdGhpcy55ID0geTtcbiAgICB0aGlzLnByZXZZID0geTtcbiAgICB0aGlzLnByZXZYID0geDtcbiAgICB0aGlzLmFuZ2xlID0gMDtcbiAgICB0aGlzLnZlbG9jaXR5ID0geyB4OiAxMCwgeTogMCB9O1xuICAgIHRoaXMubWFzcyA9IG1hc3M7XG4gICAgdGhpcy5yYWRpdXMgPSByYWRpdXM7IC8vIDFweCA9IDFjbVxuICAgIHRoaXMucmVzdGl0dXRpb24gPSAtMC44O1xuICAgIHRoaXMuQ2QgPSAwLjQ3OyAgLy8gRGltZW5zaW9ubGVzc1xuICAgIHRoaXMucmhvID0gMC40OyAvLyBrZyAvIG1eM1xuICAgIHRoaXMuQSA9IE1hdGguUEkgKiB0aGlzLnJhZGl1cyAqIHRoaXMucmFkaXVzIC8gKDEwMDAwKTsgLy8gbV4yXG4gICAgdGhpcy5hZyA9IDkuODE7ICAvLyBtIC8gc14yXG4gICAgdGhpcy53aWR0aCA9IHJhZGl1cyAqIDI7XG4gICAgdGhpcy5oZWlnaHQgPSByYWRpdXMgKiAyO1xuICB9XG5cbiAgdXBkYXRlKHsgZnJhbWVSYXRlLCB3b3JsZFdpZHRoLCB3b3JsZEhlaWdodCwgbW91c2UsIGNhbnZhcyB9KSB7XG4gICAgdGhpcy5wcmV2WSA9IHRoaXMueTtcbiAgICB0aGlzLnByZXZYID0gdGhpcy54O1xuXG4gICAgaWYgKCFtb3VzZS5pc0Rvd24pIHtcbiAgICAgIC8vIERvIHBoeXNpY3NcbiAgICAgIC8vIERyYWcgZm9yY2U6IEZkID0gLTEvMiAqIENkICogQSAqIHJobyAqIHYgKiB2XG4gICAgICBsZXQgRnggPSAtMC41ICogdGhpcy5DZCAqIHRoaXMuQSAqIHRoaXMucmhvICogdGhpcy52ZWxvY2l0eS54ICogdGhpcy52ZWxvY2l0eS54ICogdGhpcy52ZWxvY2l0eS54IC8gTWF0aC5hYnModGhpcy52ZWxvY2l0eS54KTtcbiAgICAgIGxldCBGeSA9IC0wLjUgKiB0aGlzLkNkICogdGhpcy5BICogdGhpcy5yaG8gKiB0aGlzLnZlbG9jaXR5LnkgKiB0aGlzLnZlbG9jaXR5LnkgKiB0aGlzLnZlbG9jaXR5LnkgLyBNYXRoLmFicyh0aGlzLnZlbG9jaXR5LnkpO1xuXG4gICAgICBGeCA9IChpc05hTihGeCkgPyAwIDogRngpO1xuICAgICAgRnkgPSAoaXNOYU4oRnkpID8gMCA6IEZ5KTtcblxuICAgICAgLy8gQ2FsY3VsYXRlIGFjY2VsZXJhdGlvbiAoIEYgPSBtYSApXG4gICAgICBjb25zdCBheCA9IEZ4IC8gdGhpcy5tYXNzO1xuICAgICAgY29uc3QgYXkgPSB0aGlzLmFnICsgKEZ5IC8gdGhpcy5tYXNzKTtcbiAgICAgIC8vIEludGVncmF0ZSB0byBnZXQgdmVsb2NpdHlcbiAgICAgIHRoaXMudmVsb2NpdHkueCArPSBheCAqIGZyYW1lUmF0ZTtcbiAgICAgIHRoaXMudmVsb2NpdHkueSArPSBheSAqIGZyYW1lUmF0ZTtcblxuICAgICAgLy8gSW50ZWdyYXRlIHRvIGdldCBwb3NpdGlvblxuICAgICAgdGhpcy54ICs9IHRoaXMudmVsb2NpdHkueCAqIGZyYW1lUmF0ZSAqIDEwMDtcbiAgICAgIHRoaXMueSArPSB0aGlzLnZlbG9jaXR5LnkgKiBmcmFtZVJhdGUgKiAxMDA7XG4gICAgfVxuXG4gICAgLy8gZG9uJ3QgbGV0IHBsYXllciBsZWF2ZXMgdGhlIHdvcmxkJ3MgYm91bmRhcnlcbiAgICBpZiAodGhpcy54IC0gdGhpcy53aWR0aCAvIDIgPCAwKSB7XG4gICAgICB0aGlzLnZlbG9jaXR5LnggKj0gdGhpcy5yZXN0aXR1dGlvbjtcbiAgICAgIHRoaXMueCA9IHRoaXMud2lkdGg7XG4gICAgfVxuICAgIGlmICh0aGlzLnkgLSB0aGlzLmhlaWdodCAvIDIgPCAwKSB7XG4gICAgICB0aGlzLnZlbG9jaXR5LnkgKj0gdGhpcy5yZXN0aXR1dGlvbjtcbiAgICAgIHRoaXMueSA9IHRoaXMuaGVpZ2h0O1xuICAgIH1cbiAgICBpZiAodGhpcy54ICsgdGhpcy53aWR0aCAvIDIgPiB3b3JsZFdpZHRoKSB7XG4gICAgICB0aGlzLnZlbG9jaXR5LnggKj0gdGhpcy5yZXN0aXR1dGlvbjtcbiAgICAgIHRoaXMueCA9IHdvcmxkV2lkdGggLSB0aGlzLndpZHRoIC8gMiAtIHRoaXMucmFkaXVzO1xuICAgIH1cbiAgICBpZiAodGhpcy55ICsgdGhpcy5oZWlnaHQgLyAyID4gd29ybGRIZWlnaHQpIHtcbiAgICAgIHRoaXMudmVsb2NpdHkueSAqPSB0aGlzLnJlc3RpdHV0aW9uO1xuICAgICAgdGhpcy55ID0gY2FudmFzLmhlaWdodCAtIHRoaXMucmFkaXVzO1xuICAgIH1cbiAgICBpZiAobW91c2UuaXNEb3duKSB7XG4gICAgICB0aGlzLmFuZ2xlID0gTWF0aC5hdGFuMih0aGlzLnkgLSBtb3VzZS55LCB0aGlzLnggLSBtb3VzZS54KTtcblxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmFuZ2xlID0gTWF0aC5hdGFuMih0aGlzLnkgLSB0aGlzLnByZXZZLCB0aGlzLnggLSB0aGlzLnByZXZYKTtcbiAgICB9XG4gIH1cblxuICBkcmF3KHsgY29udGV4dCwgeFZpZXcsIHlWaWV3LCBwbGF5ZXJJbWcgfSkge1xuICAgIGNvbnRleHQuc2V0VHJhbnNmb3JtKDEsIDAsIDAsIDEsIHRoaXMueCAtIHhWaWV3LCB0aGlzLnkgLSB5Vmlldyk7XG4gICAgY29udGV4dC5yb3RhdGUodGhpcy5hbmdsZSk7XG4gICAgY29udGV4dC5kcmF3SW1hZ2UocGxheWVySW1nLCAtdGhpcy5yYWRpdXMsIC10aGlzLnJhZGl1cywgdGhpcy53aWR0aCwgdGhpcy5oZWlnaHQpO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Iiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/js/components/player.js\n");

/***/ }),

/***/ "./src/js/components/textMenu.js":
/*!***************************************!*\
  !*** ./src/js/components/textMenu.js ***!
  \***************************************/
/*! namespace exports */
/*! export default [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__.r, __webpack_exports__, __webpack_require__.d, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => /* binding */ TextMenu\n/* harmony export */ });\nclass TextMenu {\n  draw(ctx, text, position) {\n    ctx.font = \"20px Impact\";\n    ctx.fillStyle = \"white\";\n    ctx.fillText(text, position.x, position.y);\n  }\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvanMvY29tcG9uZW50cy90ZXh0TWVudS5qcy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovL3JvY2tldC1nYW1lLy4vc3JjL2pzL2NvbXBvbmVudHMvdGV4dE1lbnUuanM/NjliOCJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBjbGFzcyBUZXh0TWVudSB7XG4gIGRyYXcoY3R4LCB0ZXh0LCBwb3NpdGlvbikge1xuICAgIGN0eC5mb250ID0gXCIyMHB4IEltcGFjdFwiO1xuICAgIGN0eC5maWxsU3R5bGUgPSBcIndoaXRlXCI7XG4gICAgY3R4LmZpbGxUZXh0KHRleHQsIHBvc2l0aW9uLngsIHBvc2l0aW9uLnkpO1xuICB9XG59Il0sIm1hcHBpbmdzIjoiOzs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/js/components/textMenu.js\n");

/***/ }),

/***/ "./src/js/components/worldMap.js":
/*!***************************************!*\
  !*** ./src/js/components/worldMap.js ***!
  \***************************************/
/*! namespace exports */
/*! export default [provided] [no usage info] [missing usage info prevents renaming] */
/*! other exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__.r, __webpack_exports__, __webpack_require__.d, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => /* binding */ WorldMap\n/* harmony export */ });\nclass WorldMap {\n\tconstructor(image) {\n\t\t// world texture\n\t\tthis.image = image;\n\t}\n\n\tdraw(context, xView, yView) {\n\t\t// easiest way: draw the entire map changing only the destination coordinate in canvas\n\t\t// canvas will cull the image by itself (no performance gaps -> in hardware accelerated environments, at least)\n\n\t\t// didactic way ( \"s\" is for \"source\" and \"d\" is for \"destination\" in the variable names):\n\n\t\tvar sx, sy, dx, dy;\n\t\tvar sWidth, sHeight, dWidth, dHeight;\n\n\t\t// offset point to crop the image\n\t\tsx = xView;\n\t\tsy = yView;\n\n\t\t// dimensions of cropped image\t\t\t\n\t\tsWidth = context.canvas.width;\n\t\tsHeight = context.canvas.height;\n\n\t\t// if cropped image is smaller than canvas we need to change the source dimensions\n\t\tif (this.image.width - sx < sWidth) {\n\t\t\tsWidth = this.image.width - sx;\n\t\t}\n\t\tif (this.image.height - sy < sHeight) {\n\t\t\tsHeight = this.image.height - sy;\n\t\t}\n\n\t\t// location on canvas to draw the croped image\n\t\tdx = 0;\n\t\tdy = 0;\n\t\t// match destination with source to not scale the image\n\t\tdWidth = sWidth;\n\t\tdHeight = sHeight;\n\n\t\tcontext.drawImage(this.image, sx, sy, sWidth, sHeight, dx, dy, dWidth, dHeight);\n\t}\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvanMvY29tcG9uZW50cy93b3JsZE1hcC5qcy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovL3JvY2tldC1nYW1lLy4vc3JjL2pzL2NvbXBvbmVudHMvd29ybGRNYXAuanM/ZWUzZiJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBjbGFzcyBXb3JsZE1hcCB7XG5cdGNvbnN0cnVjdG9yKGltYWdlKSB7XG5cdFx0Ly8gd29ybGQgdGV4dHVyZVxuXHRcdHRoaXMuaW1hZ2UgPSBpbWFnZTtcblx0fVxuXG5cdGRyYXcoY29udGV4dCwgeFZpZXcsIHlWaWV3KSB7XG5cdFx0Ly8gZWFzaWVzdCB3YXk6IGRyYXcgdGhlIGVudGlyZSBtYXAgY2hhbmdpbmcgb25seSB0aGUgZGVzdGluYXRpb24gY29vcmRpbmF0ZSBpbiBjYW52YXNcblx0XHQvLyBjYW52YXMgd2lsbCBjdWxsIHRoZSBpbWFnZSBieSBpdHNlbGYgKG5vIHBlcmZvcm1hbmNlIGdhcHMgLT4gaW4gaGFyZHdhcmUgYWNjZWxlcmF0ZWQgZW52aXJvbm1lbnRzLCBhdCBsZWFzdClcblxuXHRcdC8vIGRpZGFjdGljIHdheSAoIFwic1wiIGlzIGZvciBcInNvdXJjZVwiIGFuZCBcImRcIiBpcyBmb3IgXCJkZXN0aW5hdGlvblwiIGluIHRoZSB2YXJpYWJsZSBuYW1lcyk6XG5cblx0XHR2YXIgc3gsIHN5LCBkeCwgZHk7XG5cdFx0dmFyIHNXaWR0aCwgc0hlaWdodCwgZFdpZHRoLCBkSGVpZ2h0O1xuXG5cdFx0Ly8gb2Zmc2V0IHBvaW50IHRvIGNyb3AgdGhlIGltYWdlXG5cdFx0c3ggPSB4Vmlldztcblx0XHRzeSA9IHlWaWV3O1xuXG5cdFx0Ly8gZGltZW5zaW9ucyBvZiBjcm9wcGVkIGltYWdlXHRcdFx0XG5cdFx0c1dpZHRoID0gY29udGV4dC5jYW52YXMud2lkdGg7XG5cdFx0c0hlaWdodCA9IGNvbnRleHQuY2FudmFzLmhlaWdodDtcblxuXHRcdC8vIGlmIGNyb3BwZWQgaW1hZ2UgaXMgc21hbGxlciB0aGFuIGNhbnZhcyB3ZSBuZWVkIHRvIGNoYW5nZSB0aGUgc291cmNlIGRpbWVuc2lvbnNcblx0XHRpZiAodGhpcy5pbWFnZS53aWR0aCAtIHN4IDwgc1dpZHRoKSB7XG5cdFx0XHRzV2lkdGggPSB0aGlzLmltYWdlLndpZHRoIC0gc3g7XG5cdFx0fVxuXHRcdGlmICh0aGlzLmltYWdlLmhlaWdodCAtIHN5IDwgc0hlaWdodCkge1xuXHRcdFx0c0hlaWdodCA9IHRoaXMuaW1hZ2UuaGVpZ2h0IC0gc3k7XG5cdFx0fVxuXG5cdFx0Ly8gbG9jYXRpb24gb24gY2FudmFzIHRvIGRyYXcgdGhlIGNyb3BlZCBpbWFnZVxuXHRcdGR4ID0gMDtcblx0XHRkeSA9IDA7XG5cdFx0Ly8gbWF0Y2ggZGVzdGluYXRpb24gd2l0aCBzb3VyY2UgdG8gbm90IHNjYWxlIHRoZSBpbWFnZVxuXHRcdGRXaWR0aCA9IHNXaWR0aDtcblx0XHRkSGVpZ2h0ID0gc0hlaWdodDtcblxuXHRcdGNvbnRleHQuZHJhd0ltYWdlKHRoaXMuaW1hZ2UsIHN4LCBzeSwgc1dpZHRoLCBzSGVpZ2h0LCBkeCwgZHksIGRXaWR0aCwgZEhlaWdodCk7XG5cdH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Iiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/js/components/worldMap.js\n");

/***/ }),

/***/ "./src/js/index.js":
/*!*************************!*\
  !*** ./src/js/index.js ***!
  \*************************/
/*! namespace exports */
/*! exports [not provided] [no usage info] */
/*! runtime requirements: __webpack_require__, __webpack_require__.r, __webpack_exports__, __webpack_require__.* */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _components_camera_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/camera/index.js */ \"./src/js/components/camera/index.js\");\n/* harmony import */ var _components_player_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/player.js */ \"./src/js/components/player.js\");\n/* harmony import */ var _components_worldMap_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/worldMap.js */ \"./src/js/components/worldMap.js\");\n/* harmony import */ var _components_textMenu_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/textMenu.js */ \"./src/js/components/textMenu.js\");\n/* harmony import */ var _components_drag_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/drag.js */ \"./src/js/components/drag.js\");\n/* harmony import */ var _components_asteroid_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/asteroid.js */ \"./src/js/components/asteroid.js\");\n\n\n\n\n\n\n\ndocument.addEventListener(\"DOMContentLoaded\", () => {\n\n  // Config\n  const playerRadius = 25;\n  const asteroidRadius = 25;\n  const asteroidColor = 'gold';\n  const playerMass = 0.1;  //kg\n  let frameRate = 1 / 60; // Seconds\n  let isPaused = false;\n  let isReady = false;\n\n  // Selectors\n  const canvas = document.getElementById('js-canvas');\n  const pauseBtn = document.getElementById('js-pause');\n  const radioBtn = document.querySelectorAll('input[name=\"speed\"]');\n\n  // Canvas\n  const ctx = canvas.getContext('2d');\n\n  // Mouse events\n  const mouse = { x: 0, y: 0, isDown: false };\n  const getMousePosition = e => {\n    mouse.x = e.pageX - canvas.offsetLeft;\n    mouse.y = e.pageY - canvas.offsetTop;\n  }\n  const mouseDown = e => {\n    if (e.which == 1) {\n      getMousePosition(e);\n      mouse.isDown = true;\n      if (!isPaused) {\n        player.x = mouse.x;\n        player.y = mouse.y;\n      }\n    }\n  }\n  const mouseUp = e => {\n    if (e.which == 1) {\n      mouse.isDown = false;\n      player.velocity.y = (player.y - mouse.y) / 10;\n      player.velocity.x = (player.x - mouse.x) / 10;\n    }\n  }\n\n  // Listeners\n  let lastIndex = radioBtn.length;\n  while (lastIndex--)\n    radioBtn[lastIndex].addEventListener('change', (e) => {\n      frameRate = 1 / (e.target.value * 20);\n    }, 0);\n  pauseBtn.addEventListener('click', () => {\n    isPaused = !isPaused;\n  });\n  canvas.onmousemove = getMousePosition;\n  canvas.onmousedown = mouseDown;\n  canvas.onmouseup = mouseUp;\n\n  // Game objects\n  const rocket = new Image();\n  rocket.src = './images/startup.svg';\n  const sky = new Image();\n  sky.src = './images/bg.jpg';\n  const text = new _components_textMenu_js__WEBPACK_IMPORTED_MODULE_3__.default();\n  const drag = new _components_drag_js__WEBPACK_IMPORTED_MODULE_4__.default();\n  const asteroid = new _components_asteroid_js__WEBPACK_IMPORTED_MODULE_5__.default(600, canvas.height / 2 - asteroidRadius, asteroidRadius, asteroidColor);\n  const player = new _components_player_js__WEBPACK_IMPORTED_MODULE_1__.default(350, 350, playerRadius, playerMass);\n  const world = {\n    width: canvas.width * 2,\n    height: canvas.height,\n    map: new _components_worldMap_js__WEBPACK_IMPORTED_MODULE_2__.default(sky)\n  };\n\n  // Camera settings\n  const vWidth = Math.min(world.width, canvas.width);\n  const vHeight = Math.min(world.height, canvas.height);\n  const camera = new _components_camera_index_js__WEBPACK_IMPORTED_MODULE_0__.default(0, 0, vWidth, vHeight, world.width, world.height);\n  camera.follow(player, vWidth / 2, vHeight / 2);\n\n  // Images Loading\n  const images = [sky, rocket];\n  const imageCount = images.length;\n  let imagesLoaded = 0;\n  for (let i = 0; i < imageCount; i++) {\n    images[i].onload = () => {\n      imagesLoaded++;\n      if (imagesLoaded === imageCount) {\n        allImagesLoaded();\n      }\n    }\n  }\n  const allImagesLoaded = () => {\n    isReady = true;\n  }\n\n  // Collision\n  const collisionDetection = () => {\n    if (\n      asteroid.x > (player.x - asteroid.width) &&\n      asteroid.x < (player.x + asteroid.width) &&\n      asteroid.y > (player.y - asteroid.height) &&\n      asteroid.y < (player.y + asteroid.height)) {\n      player.velocity.x *= player.restitution;\n      player.velocity.y *= player.restitution;\n      player.x = player.x - playerRadius;\n      player.y = player.y - playerRadius;\n      asteroid.color = '#' + ((1 << 24) * Math.random() | 0).toString(16);\n    }\n  }\n\n  // Game update function\n  const update = () => {\n    player.update({\n      frameRate,\n      worldWidth: world.width,\n      worldHeight: world.height,\n      mouse,\n      canvas,\n    });\n    camera.update();\n    collisionDetection();\n  }\n\n  // Game draw function\n  const draw = () => {\n    ctx.setTransform(1, 0, 0, 1, 0, 0);\n    // clear the entire canvas\n    ctx.clearRect(0, 0, canvas.width, canvas.height);\n    world.map.draw(ctx, camera.xView, camera.yView);\n    drag.draw(ctx, player.x - camera.xView, player.y - camera.yView, mouse);\n    text.draw(ctx, `Distance: ${parseInt(player.x)}`, { x: 20, y: 40 });\n    text.draw(ctx, `Speed: ${frameRate.toFixed(2)}`, { x: 180, y: 40 });\n    asteroid.draw(ctx, camera.xView, camera.yView);\n    if (isPaused) {\n      text.draw(ctx, 'Set new parameters', { x: canvas.width / 2 - 100, y: canvas.height / 2 - 100 });\n    }\n    player.draw({ context: ctx, xView: camera.xView, yView: camera.yView, playerImg: rocket });\n  }\n\n  const render = () => {\n    if (!isPaused) {\n      update();\n    }\n    if (isReady) {\n      draw();\n    }\n    window.requestAnimationFrame(render);\n  }\n\n  render();\n\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvanMvaW5kZXguanMuanMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yb2NrZXQtZ2FtZS8uL3NyYy9qcy9pbmRleC5qcz83YmE1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBDYW1lcmEgZnJvbSAnLi9jb21wb25lbnRzL2NhbWVyYS9pbmRleC5qcyc7XG5pbXBvcnQgUGxheWVyIGZyb20gJy4vY29tcG9uZW50cy9wbGF5ZXIuanMnO1xuaW1wb3J0IFdvcmxkTWFwIGZyb20gJy4vY29tcG9uZW50cy93b3JsZE1hcC5qcyc7XG5pbXBvcnQgTWVudSBmcm9tICcuL2NvbXBvbmVudHMvdGV4dE1lbnUuanMnO1xuaW1wb3J0IERyYWcgZnJvbSAnLi9jb21wb25lbnRzL2RyYWcuanMnO1xuaW1wb3J0IEFzdGVyb2lkIGZyb20gJy4vY29tcG9uZW50cy9hc3Rlcm9pZC5qcyc7XG5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsICgpID0+IHtcblxuICAvLyBDb25maWdcbiAgY29uc3QgcGxheWVyUmFkaXVzID0gMjU7XG4gIGNvbnN0IGFzdGVyb2lkUmFkaXVzID0gMjU7XG4gIGNvbnN0IGFzdGVyb2lkQ29sb3IgPSAnZ29sZCc7XG4gIGNvbnN0IHBsYXllck1hc3MgPSAwLjE7ICAvL2tnXG4gIGxldCBmcmFtZVJhdGUgPSAxIC8gNjA7IC8vIFNlY29uZHNcbiAgbGV0IGlzUGF1c2VkID0gZmFsc2U7XG4gIGxldCBpc1JlYWR5ID0gZmFsc2U7XG5cbiAgLy8gU2VsZWN0b3JzXG4gIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdqcy1jYW52YXMnKTtcbiAgY29uc3QgcGF1c2VCdG4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnanMtcGF1c2UnKTtcbiAgY29uc3QgcmFkaW9CdG4gPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdpbnB1dFtuYW1lPVwic3BlZWRcIl0nKTtcblxuICAvLyBDYW52YXNcbiAgY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoJzJkJyk7XG5cbiAgLy8gTW91c2UgZXZlbnRzXG4gIGNvbnN0IG1vdXNlID0geyB4OiAwLCB5OiAwLCBpc0Rvd246IGZhbHNlIH07XG4gIGNvbnN0IGdldE1vdXNlUG9zaXRpb24gPSBlID0+IHtcbiAgICBtb3VzZS54ID0gZS5wYWdlWCAtIGNhbnZhcy5vZmZzZXRMZWZ0O1xuICAgIG1vdXNlLnkgPSBlLnBhZ2VZIC0gY2FudmFzLm9mZnNldFRvcDtcbiAgfVxuICBjb25zdCBtb3VzZURvd24gPSBlID0+IHtcbiAgICBpZiAoZS53aGljaCA9PSAxKSB7XG4gICAgICBnZXRNb3VzZVBvc2l0aW9uKGUpO1xuICAgICAgbW91c2UuaXNEb3duID0gdHJ1ZTtcbiAgICAgIGlmICghaXNQYXVzZWQpIHtcbiAgICAgICAgcGxheWVyLnggPSBtb3VzZS54O1xuICAgICAgICBwbGF5ZXIueSA9IG1vdXNlLnk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvbnN0IG1vdXNlVXAgPSBlID0+IHtcbiAgICBpZiAoZS53aGljaCA9PSAxKSB7XG4gICAgICBtb3VzZS5pc0Rvd24gPSBmYWxzZTtcbiAgICAgIHBsYXllci52ZWxvY2l0eS55ID0gKHBsYXllci55IC0gbW91c2UueSkgLyAxMDtcbiAgICAgIHBsYXllci52ZWxvY2l0eS54ID0gKHBsYXllci54IC0gbW91c2UueCkgLyAxMDtcbiAgICB9XG4gIH1cblxuICAvLyBMaXN0ZW5lcnNcbiAgbGV0IGxhc3RJbmRleCA9IHJhZGlvQnRuLmxlbmd0aDtcbiAgd2hpbGUgKGxhc3RJbmRleC0tKVxuICAgIHJhZGlvQnRuW2xhc3RJbmRleF0uYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKGUpID0+IHtcbiAgICAgIGZyYW1lUmF0ZSA9IDEgLyAoZS50YXJnZXQudmFsdWUgKiAyMCk7XG4gICAgfSwgMCk7XG4gIHBhdXNlQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlzUGF1c2VkID0gIWlzUGF1c2VkO1xuICB9KTtcbiAgY2FudmFzLm9ubW91c2Vtb3ZlID0gZ2V0TW91c2VQb3NpdGlvbjtcbiAgY2FudmFzLm9ubW91c2Vkb3duID0gbW91c2VEb3duO1xuICBjYW52YXMub25tb3VzZXVwID0gbW91c2VVcDtcblxuICAvLyBHYW1lIG9iamVjdHNcbiAgY29uc3Qgcm9ja2V0ID0gbmV3IEltYWdlKCk7XG4gIHJvY2tldC5zcmMgPSAnLi9pbWFnZXMvc3RhcnR1cC5zdmcnO1xuICBjb25zdCBza3kgPSBuZXcgSW1hZ2UoKTtcbiAgc2t5LnNyYyA9ICcuL2ltYWdlcy9iZy5qcGcnO1xuICBjb25zdCB0ZXh0ID0gbmV3IE1lbnUoKTtcbiAgY29uc3QgZHJhZyA9IG5ldyBEcmFnKCk7XG4gIGNvbnN0IGFzdGVyb2lkID0gbmV3IEFzdGVyb2lkKDYwMCwgY2FudmFzLmhlaWdodCAvIDIgLSBhc3Rlcm9pZFJhZGl1cywgYXN0ZXJvaWRSYWRpdXMsIGFzdGVyb2lkQ29sb3IpO1xuICBjb25zdCBwbGF5ZXIgPSBuZXcgUGxheWVyKDM1MCwgMzUwLCBwbGF5ZXJSYWRpdXMsIHBsYXllck1hc3MpO1xuICBjb25zdCB3b3JsZCA9IHtcbiAgICB3aWR0aDogY2FudmFzLndpZHRoICogMixcbiAgICBoZWlnaHQ6IGNhbnZhcy5oZWlnaHQsXG4gICAgbWFwOiBuZXcgV29ybGRNYXAoc2t5KVxuICB9O1xuXG4gIC8vIENhbWVyYSBzZXR0aW5nc1xuICBjb25zdCB2V2lkdGggPSBNYXRoLm1pbih3b3JsZC53aWR0aCwgY2FudmFzLndpZHRoKTtcbiAgY29uc3QgdkhlaWdodCA9IE1hdGgubWluKHdvcmxkLmhlaWdodCwgY2FudmFzLmhlaWdodCk7XG4gIGNvbnN0IGNhbWVyYSA9IG5ldyBDYW1lcmEoMCwgMCwgdldpZHRoLCB2SGVpZ2h0LCB3b3JsZC53aWR0aCwgd29ybGQuaGVpZ2h0KTtcbiAgY2FtZXJhLmZvbGxvdyhwbGF5ZXIsIHZXaWR0aCAvIDIsIHZIZWlnaHQgLyAyKTtcblxuICAvLyBJbWFnZXMgTG9hZGluZ1xuICBjb25zdCBpbWFnZXMgPSBbc2t5LCByb2NrZXRdO1xuICBjb25zdCBpbWFnZUNvdW50ID0gaW1hZ2VzLmxlbmd0aDtcbiAgbGV0IGltYWdlc0xvYWRlZCA9IDA7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgaW1hZ2VDb3VudDsgaSsrKSB7XG4gICAgaW1hZ2VzW2ldLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgIGltYWdlc0xvYWRlZCsrO1xuICAgICAgaWYgKGltYWdlc0xvYWRlZCA9PT0gaW1hZ2VDb3VudCkge1xuICAgICAgICBhbGxJbWFnZXNMb2FkZWQoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgY29uc3QgYWxsSW1hZ2VzTG9hZGVkID0gKCkgPT4ge1xuICAgIGlzUmVhZHkgPSB0cnVlO1xuICB9XG5cbiAgLy8gQ29sbGlzaW9uXG4gIGNvbnN0IGNvbGxpc2lvbkRldGVjdGlvbiA9ICgpID0+IHtcbiAgICBpZiAoXG4gICAgICBhc3Rlcm9pZC54ID4gKHBsYXllci54IC0gYXN0ZXJvaWQud2lkdGgpICYmXG4gICAgICBhc3Rlcm9pZC54IDwgKHBsYXllci54ICsgYXN0ZXJvaWQud2lkdGgpICYmXG4gICAgICBhc3Rlcm9pZC55ID4gKHBsYXllci55IC0gYXN0ZXJvaWQuaGVpZ2h0KSAmJlxuICAgICAgYXN0ZXJvaWQueSA8IChwbGF5ZXIueSArIGFzdGVyb2lkLmhlaWdodCkpIHtcbiAgICAgIHBsYXllci52ZWxvY2l0eS54ICo9IHBsYXllci5yZXN0aXR1dGlvbjtcbiAgICAgIHBsYXllci52ZWxvY2l0eS55ICo9IHBsYXllci5yZXN0aXR1dGlvbjtcbiAgICAgIHBsYXllci54ID0gcGxheWVyLnggLSBwbGF5ZXJSYWRpdXM7XG4gICAgICBwbGF5ZXIueSA9IHBsYXllci55IC0gcGxheWVyUmFkaXVzO1xuICAgICAgYXN0ZXJvaWQuY29sb3IgPSAnIycgKyAoKDEgPDwgMjQpICogTWF0aC5yYW5kb20oKSB8IDApLnRvU3RyaW5nKDE2KTtcbiAgICB9XG4gIH1cblxuICAvLyBHYW1lIHVwZGF0ZSBmdW5jdGlvblxuICBjb25zdCB1cGRhdGUgPSAoKSA9PiB7XG4gICAgcGxheWVyLnVwZGF0ZSh7XG4gICAgICBmcmFtZVJhdGUsXG4gICAgICB3b3JsZFdpZHRoOiB3b3JsZC53aWR0aCxcbiAgICAgIHdvcmxkSGVpZ2h0OiB3b3JsZC5oZWlnaHQsXG4gICAgICBtb3VzZSxcbiAgICAgIGNhbnZhcyxcbiAgICB9KTtcbiAgICBjYW1lcmEudXBkYXRlKCk7XG4gICAgY29sbGlzaW9uRGV0ZWN0aW9uKCk7XG4gIH1cblxuICAvLyBHYW1lIGRyYXcgZnVuY3Rpb25cbiAgY29uc3QgZHJhdyA9ICgpID0+IHtcbiAgICBjdHguc2V0VHJhbnNmb3JtKDEsIDAsIDAsIDEsIDAsIDApO1xuICAgIC8vIGNsZWFyIHRoZSBlbnRpcmUgY2FudmFzXG4gICAgY3R4LmNsZWFyUmVjdCgwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgIHdvcmxkLm1hcC5kcmF3KGN0eCwgY2FtZXJhLnhWaWV3LCBjYW1lcmEueVZpZXcpO1xuICAgIGRyYWcuZHJhdyhjdHgsIHBsYXllci54IC0gY2FtZXJhLnhWaWV3LCBwbGF5ZXIueSAtIGNhbWVyYS55VmlldywgbW91c2UpO1xuICAgIHRleHQuZHJhdyhjdHgsIGBEaXN0YW5jZTogJHtwYXJzZUludChwbGF5ZXIueCl9YCwgeyB4OiAyMCwgeTogNDAgfSk7XG4gICAgdGV4dC5kcmF3KGN0eCwgYFNwZWVkOiAke2ZyYW1lUmF0ZS50b0ZpeGVkKDIpfWAsIHsgeDogMTgwLCB5OiA0MCB9KTtcbiAgICBhc3Rlcm9pZC5kcmF3KGN0eCwgY2FtZXJhLnhWaWV3LCBjYW1lcmEueVZpZXcpO1xuICAgIGlmIChpc1BhdXNlZCkge1xuICAgICAgdGV4dC5kcmF3KGN0eCwgJ1NldCBuZXcgcGFyYW1ldGVycycsIHsgeDogY2FudmFzLndpZHRoIC8gMiAtIDEwMCwgeTogY2FudmFzLmhlaWdodCAvIDIgLSAxMDAgfSk7XG4gICAgfVxuICAgIHBsYXllci5kcmF3KHsgY29udGV4dDogY3R4LCB4VmlldzogY2FtZXJhLnhWaWV3LCB5VmlldzogY2FtZXJhLnlWaWV3LCBwbGF5ZXJJbWc6IHJvY2tldCB9KTtcbiAgfVxuXG4gIGNvbnN0IHJlbmRlciA9ICgpID0+IHtcbiAgICBpZiAoIWlzUGF1c2VkKSB7XG4gICAgICB1cGRhdGUoKTtcbiAgICB9XG4gICAgaWYgKGlzUmVhZHkpIHtcbiAgICAgIGRyYXcoKTtcbiAgICB9XG4gICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZShyZW5kZXIpO1xuICB9XG5cbiAgcmVuZGVyKCk7XG5cbn0pO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Iiwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/js/index.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		if(__webpack_module_cache__[moduleId]) {
/******/ 			return __webpack_module_cache__[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		var execOptions = { id: moduleId, module: module, factory: __webpack_modules__[moduleId], require: __webpack_require__ };
/******/ 		__webpack_require__.i.forEach(function(handler) { handler(execOptions); });
/******/ 		module = execOptions.module;
/******/ 		execOptions.factory.call(module.exports, module, module.exports, execOptions.require);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = __webpack_module_cache__;
/******/ 	
/******/ 	// expose the module execution interceptor
/******/ 	__webpack_require__.i = [];
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => module['default'] :
/******/ 				() => module;
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript update chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference all chunks
/******/ 		__webpack_require__.hu = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + "." + __webpack_require__.h() + ".hot-update.js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get update manifest filename */
/******/ 	(() => {
/******/ 		__webpack_require__.hmrF = () => "" + __webpack_require__.h() + ".hot-update.json";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/getFullHash */
/******/ 	(() => {
/******/ 		__webpack_require__.h = () => "bbfc26c5bee879598e22"
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => Object.prototype.hasOwnProperty.call(obj, prop)
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "rocket-game:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => fn(event));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			;
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hot module replacement */
/******/ 	(() => {
/******/ 		var currentModuleData = {};
/******/ 		var installedModules = __webpack_require__.c;
/******/ 		
/******/ 		// module and require creation
/******/ 		var currentChildModule;
/******/ 		var currentParents = [];
/******/ 		
/******/ 		// status
/******/ 		var registeredStatusHandlers = [];
/******/ 		var currentStatus = "idle";
/******/ 		
/******/ 		// while downloading
/******/ 		var blockingPromises;
/******/ 		
/******/ 		// The update info
/******/ 		var currentUpdateApplyHandlers;
/******/ 		var queuedInvalidatedModules;
/******/ 		
/******/ 		__webpack_require__.hmrD = currentModuleData;
/******/ 		
/******/ 		__webpack_require__.i.push(function (options) {
/******/ 			var module = options.module;
/******/ 			var require = createRequire(options.require, options.id);
/******/ 			module.hot = createModuleHotObject(options.id, module);
/******/ 			module.parents = currentParents;
/******/ 			module.children = [];
/******/ 			currentParents = [];
/******/ 			options.require = require;
/******/ 		});
/******/ 		
/******/ 		__webpack_require__.hmrC = {};
/******/ 		__webpack_require__.hmrI = {};
/******/ 		
/******/ 		function createRequire(require, moduleId) {
/******/ 			var me = installedModules[moduleId];
/******/ 			if (!me) return require;
/******/ 			var fn = function (request) {
/******/ 				if (me.hot.active) {
/******/ 					if (installedModules[request]) {
/******/ 						var parents = installedModules[request].parents;
/******/ 						if (parents.indexOf(moduleId) === -1) {
/******/ 							parents.push(moduleId);
/******/ 						}
/******/ 					} else {
/******/ 						currentParents = [moduleId];
/******/ 						currentChildModule = request;
/******/ 					}
/******/ 					if (me.children.indexOf(request) === -1) {
/******/ 						me.children.push(request);
/******/ 					}
/******/ 				} else {
/******/ 					console.warn(
/******/ 						"[HMR] unexpected require(" +
/******/ 							request +
/******/ 							") from disposed module " +
/******/ 							moduleId
/******/ 					);
/******/ 					currentParents = [];
/******/ 				}
/******/ 				return require(request);
/******/ 			};
/******/ 			var createPropertyDescriptor = function (name) {
/******/ 				return {
/******/ 					configurable: true,
/******/ 					enumerable: true,
/******/ 					get: function () {
/******/ 						return require[name];
/******/ 					},
/******/ 					set: function (value) {
/******/ 						require[name] = value;
/******/ 					}
/******/ 				};
/******/ 			};
/******/ 			for (var name in require) {
/******/ 				if (Object.prototype.hasOwnProperty.call(require, name) && name !== "e") {
/******/ 					Object.defineProperty(fn, name, createPropertyDescriptor(name));
/******/ 				}
/******/ 			}
/******/ 			fn.e = function (chunkId) {
/******/ 				return trackBlockingPromise(require.e(chunkId));
/******/ 			};
/******/ 			return fn;
/******/ 		}
/******/ 		
/******/ 		function createModuleHotObject(moduleId, me) {
/******/ 			var hot = {
/******/ 				// private stuff
/******/ 				_acceptedDependencies: {},
/******/ 				_declinedDependencies: {},
/******/ 				_selfAccepted: false,
/******/ 				_selfDeclined: false,
/******/ 				_selfInvalidated: false,
/******/ 				_disposeHandlers: [],
/******/ 				_main: currentChildModule !== moduleId,
/******/ 				_requireSelf: function () {
/******/ 					currentParents = me.parents.slice();
/******/ 					currentChildModule = moduleId;
/******/ 					__webpack_require__(moduleId);
/******/ 				},
/******/ 		
/******/ 				// Module API
/******/ 				active: true,
/******/ 				accept: function (dep, callback) {
/******/ 					if (dep === undefined) hot._selfAccepted = true;
/******/ 					else if (typeof dep === "function") hot._selfAccepted = dep;
/******/ 					else if (typeof dep === "object" && dep !== null)
/******/ 						for (var i = 0; i < dep.length; i++)
/******/ 							hot._acceptedDependencies[dep[i]] = callback || function () {};
/******/ 					else hot._acceptedDependencies[dep] = callback || function () {};
/******/ 				},
/******/ 				decline: function (dep) {
/******/ 					if (dep === undefined) hot._selfDeclined = true;
/******/ 					else if (typeof dep === "object" && dep !== null)
/******/ 						for (var i = 0; i < dep.length; i++)
/******/ 							hot._declinedDependencies[dep[i]] = true;
/******/ 					else hot._declinedDependencies[dep] = true;
/******/ 				},
/******/ 				dispose: function (callback) {
/******/ 					hot._disposeHandlers.push(callback);
/******/ 				},
/******/ 				addDisposeHandler: function (callback) {
/******/ 					hot._disposeHandlers.push(callback);
/******/ 				},
/******/ 				removeDisposeHandler: function (callback) {
/******/ 					var idx = hot._disposeHandlers.indexOf(callback);
/******/ 					if (idx >= 0) hot._disposeHandlers.splice(idx, 1);
/******/ 				},
/******/ 				invalidate: function () {
/******/ 					this._selfInvalidated = true;
/******/ 					switch (currentStatus) {
/******/ 						case "idle":
/******/ 							currentUpdateApplyHandlers = [];
/******/ 							Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 								__webpack_require__.hmrI[key](
/******/ 									moduleId,
/******/ 									currentUpdateApplyHandlers
/******/ 								);
/******/ 							});
/******/ 							setStatus("ready");
/******/ 							break;
/******/ 						case "ready":
/******/ 							Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 								__webpack_require__.hmrI[key](
/******/ 									moduleId,
/******/ 									currentUpdateApplyHandlers
/******/ 								);
/******/ 							});
/******/ 							break;
/******/ 						case "prepare":
/******/ 						case "check":
/******/ 						case "dispose":
/******/ 						case "apply":
/******/ 							(queuedInvalidatedModules = queuedInvalidatedModules || []).push(
/******/ 								moduleId
/******/ 							);
/******/ 							break;
/******/ 						default:
/******/ 							// ignore requests in error states
/******/ 							break;
/******/ 					}
/******/ 				},
/******/ 		
/******/ 				// Management API
/******/ 				check: hotCheck,
/******/ 				apply: hotApply,
/******/ 				status: function (l) {
/******/ 					if (!l) return currentStatus;
/******/ 					registeredStatusHandlers.push(l);
/******/ 				},
/******/ 				addStatusHandler: function (l) {
/******/ 					registeredStatusHandlers.push(l);
/******/ 				},
/******/ 				removeStatusHandler: function (l) {
/******/ 					var idx = registeredStatusHandlers.indexOf(l);
/******/ 					if (idx >= 0) registeredStatusHandlers.splice(idx, 1);
/******/ 				},
/******/ 		
/******/ 				//inherit from previous dispose call
/******/ 				data: currentModuleData[moduleId]
/******/ 			};
/******/ 			currentChildModule = undefined;
/******/ 			return hot;
/******/ 		}
/******/ 		
/******/ 		function setStatus(newStatus) {
/******/ 			currentStatus = newStatus;
/******/ 			for (var i = 0; i < registeredStatusHandlers.length; i++)
/******/ 				registeredStatusHandlers[i].call(null, newStatus);
/******/ 		}
/******/ 		
/******/ 		function trackBlockingPromise(promise) {
/******/ 			switch (currentStatus) {
/******/ 				case "ready":
/******/ 					setStatus("prepare");
/******/ 					blockingPromises.push(promise);
/******/ 					waitForBlockingPromises(function () {
/******/ 						setStatus("ready");
/******/ 					});
/******/ 					return promise;
/******/ 				case "prepare":
/******/ 					blockingPromises.push(promise);
/******/ 					return promise;
/******/ 				default:
/******/ 					return promise;
/******/ 			}
/******/ 		}
/******/ 		
/******/ 		function waitForBlockingPromises(fn) {
/******/ 			if (blockingPromises.length === 0) return fn();
/******/ 			var blocker = blockingPromises;
/******/ 			blockingPromises = [];
/******/ 			return Promise.all(blocker).then(function () {
/******/ 				return waitForBlockingPromises(fn);
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		function hotCheck(applyOnUpdate) {
/******/ 			if (currentStatus !== "idle") {
/******/ 				throw new Error("check() is only allowed in idle status");
/******/ 			}
/******/ 			setStatus("check");
/******/ 			return __webpack_require__.hmrM().then(function (update) {
/******/ 				if (!update) {
/******/ 					setStatus(applyInvalidatedModules() ? "ready" : "idle");
/******/ 					return null;
/******/ 				}
/******/ 		
/******/ 				setStatus("prepare");
/******/ 		
/******/ 				var updatedModules = [];
/******/ 				blockingPromises = [];
/******/ 				currentUpdateApplyHandlers = [];
/******/ 		
/******/ 				return Promise.all(
/******/ 					Object.keys(__webpack_require__.hmrC).reduce(function (
/******/ 						promises,
/******/ 						key
/******/ 					) {
/******/ 						__webpack_require__.hmrC[key](
/******/ 							update.c,
/******/ 							update.r,
/******/ 							update.m,
/******/ 							promises,
/******/ 							currentUpdateApplyHandlers,
/******/ 							updatedModules
/******/ 						);
/******/ 						return promises;
/******/ 					},
/******/ 					[])
/******/ 				).then(function () {
/******/ 					return waitForBlockingPromises(function () {
/******/ 						if (applyOnUpdate) {
/******/ 							return internalApply(applyOnUpdate);
/******/ 						} else {
/******/ 							setStatus("ready");
/******/ 		
/******/ 							return updatedModules;
/******/ 						}
/******/ 					});
/******/ 				});
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		function hotApply(options) {
/******/ 			if (currentStatus !== "ready") {
/******/ 				return Promise.resolve().then(function () {
/******/ 					throw new Error("apply() is only allowed in ready status");
/******/ 				});
/******/ 			}
/******/ 			return internalApply(options);
/******/ 		}
/******/ 		
/******/ 		function internalApply(options) {
/******/ 			options = options || {};
/******/ 		
/******/ 			applyInvalidatedModules();
/******/ 		
/******/ 			var results = currentUpdateApplyHandlers.map(function (handler) {
/******/ 				return handler(options);
/******/ 			});
/******/ 			currentUpdateApplyHandlers = undefined;
/******/ 		
/******/ 			var errors = results
/******/ 				.map(function (r) {
/******/ 					return r.error;
/******/ 				})
/******/ 				.filter(Boolean);
/******/ 		
/******/ 			if (errors.length > 0) {
/******/ 				setStatus("abort");
/******/ 				return Promise.resolve().then(function () {
/******/ 					throw errors[0];
/******/ 				});
/******/ 			}
/******/ 		
/******/ 			// Now in "dispose" phase
/******/ 			setStatus("dispose");
/******/ 		
/******/ 			results.forEach(function (result) {
/******/ 				if (result.dispose) result.dispose();
/******/ 			});
/******/ 		
/******/ 			// Now in "apply" phase
/******/ 			setStatus("apply");
/******/ 		
/******/ 			var error;
/******/ 			var reportError = function (err) {
/******/ 				if (!error) error = err;
/******/ 			};
/******/ 		
/******/ 			var outdatedModules = [];
/******/ 			results.forEach(function (result) {
/******/ 				if (result.apply) {
/******/ 					var modules = result.apply(reportError);
/******/ 					if (modules) {
/******/ 						for (var i = 0; i < modules.length; i++) {
/******/ 							outdatedModules.push(modules[i]);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 			});
/******/ 		
/******/ 			// handle errors in accept handlers and self accepted module load
/******/ 			if (error) {
/******/ 				setStatus("fail");
/******/ 				return Promise.resolve().then(function () {
/******/ 					throw error;
/******/ 				});
/******/ 			}
/******/ 		
/******/ 			if (queuedInvalidatedModules) {
/******/ 				return internalApply(options).then(function (list) {
/******/ 					outdatedModules.forEach(function (moduleId) {
/******/ 						if (list.indexOf(moduleId) < 0) list.push(moduleId);
/******/ 					});
/******/ 					return list;
/******/ 				});
/******/ 			}
/******/ 		
/******/ 			setStatus("idle");
/******/ 			return Promise.resolve(outdatedModules);
/******/ 		}
/******/ 		
/******/ 		function applyInvalidatedModules() {
/******/ 			if (queuedInvalidatedModules) {
/******/ 				if (!currentUpdateApplyHandlers) currentUpdateApplyHandlers = [];
/******/ 				Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 					queuedInvalidatedModules.forEach(function (moduleId) {
/******/ 						__webpack_require__.hmrI[key](
/******/ 							moduleId,
/******/ 							currentUpdateApplyHandlers
/******/ 						);
/******/ 					});
/******/ 				});
/******/ 				queuedInvalidatedModules = undefined;
/******/ 				return true;
/******/ 			}
/******/ 		}
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		__webpack_require__.p = "/";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// Promise = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"main": 0
/******/ 		};
/******/ 		
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		var currentUpdatedModulesList;
/******/ 		var waitingUpdateResolves = {};
/******/ 		function loadUpdateChunk(chunkId) {
/******/ 			return new Promise((resolve, reject) => {
/******/ 				waitingUpdateResolves[chunkId] = resolve;
/******/ 				// start update chunk loading
/******/ 				var url = __webpack_require__.p + __webpack_require__.hu(chunkId);
/******/ 				// create error before stack unwound to get useful stacktrace later
/******/ 				var error = new Error();
/******/ 				var loadingEnded = (event) => {
/******/ 					if(waitingUpdateResolves[chunkId]) {
/******/ 						waitingUpdateResolves[chunkId] = undefined
/******/ 						var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 						var realSrc = event && event.target && event.target.src;
/******/ 						error.message = 'Loading hot update chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 						error.name = 'ChunkLoadError';
/******/ 						error.type = errorType;
/******/ 						error.request = realSrc;
/******/ 						reject(error);
/******/ 					}
/******/ 				};
/******/ 				__webpack_require__.l(url, loadingEnded);
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		self["webpackHotUpdaterocket_game"] = (chunkId, moreModules, runtime) => {
/******/ 			for(var moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					currentUpdate[moduleId] = moreModules[moduleId];
/******/ 					if(currentUpdatedModulesList) currentUpdatedModulesList.push(moduleId);
/******/ 				}
/******/ 			}
/******/ 			if(runtime) currentUpdateRuntime.push(runtime);
/******/ 			if(waitingUpdateResolves[chunkId]) {
/******/ 				waitingUpdateResolves[chunkId]();
/******/ 				waitingUpdateResolves[chunkId] = undefined;
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		var currentUpdateChunks;
/******/ 		var currentUpdate;
/******/ 		var currentUpdateRemovedChunks;
/******/ 		var currentUpdateRuntime;
/******/ 		function applyHandler(options) {
/******/ 			if (__webpack_require__.f) delete __webpack_require__.f.jsonpHmr;
/******/ 			currentUpdateChunks = undefined;
/******/ 			function getAffectedModuleEffects(updateModuleId) {
/******/ 				var outdatedModules = [updateModuleId];
/******/ 				var outdatedDependencies = {};
/******/ 		
/******/ 				var queue = outdatedModules.map(function (id) {
/******/ 					return {
/******/ 						chain: [id],
/******/ 						id: id
/******/ 					};
/******/ 				});
/******/ 				while (queue.length > 0) {
/******/ 					var queueItem = queue.pop();
/******/ 					var moduleId = queueItem.id;
/******/ 					var chain = queueItem.chain;
/******/ 					var module = __webpack_require__.c[moduleId];
/******/ 					if (
/******/ 						!module ||
/******/ 						(module.hot._selfAccepted && !module.hot._selfInvalidated)
/******/ 					)
/******/ 						continue;
/******/ 					if (module.hot._selfDeclined) {
/******/ 						return {
/******/ 							type: "self-declined",
/******/ 							chain: chain,
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					if (module.hot._main) {
/******/ 						return {
/******/ 							type: "unaccepted",
/******/ 							chain: chain,
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					for (var i = 0; i < module.parents.length; i++) {
/******/ 						var parentId = module.parents[i];
/******/ 						var parent = __webpack_require__.c[parentId];
/******/ 						if (!parent) continue;
/******/ 						if (parent.hot._declinedDependencies[moduleId]) {
/******/ 							return {
/******/ 								type: "declined",
/******/ 								chain: chain.concat([parentId]),
/******/ 								moduleId: moduleId,
/******/ 								parentId: parentId
/******/ 							};
/******/ 						}
/******/ 						if (outdatedModules.indexOf(parentId) !== -1) continue;
/******/ 						if (parent.hot._acceptedDependencies[moduleId]) {
/******/ 							if (!outdatedDependencies[parentId])
/******/ 								outdatedDependencies[parentId] = [];
/******/ 							addAllToSet(outdatedDependencies[parentId], [moduleId]);
/******/ 							continue;
/******/ 						}
/******/ 						delete outdatedDependencies[parentId];
/******/ 						outdatedModules.push(parentId);
/******/ 						queue.push({
/******/ 							chain: chain.concat([parentId]),
/******/ 							id: parentId
/******/ 						});
/******/ 					}
/******/ 				}
/******/ 		
/******/ 				return {
/******/ 					type: "accepted",
/******/ 					moduleId: updateModuleId,
/******/ 					outdatedModules: outdatedModules,
/******/ 					outdatedDependencies: outdatedDependencies
/******/ 				};
/******/ 			}
/******/ 		
/******/ 			function addAllToSet(a, b) {
/******/ 				for (var i = 0; i < b.length; i++) {
/******/ 					var item = b[i];
/******/ 					if (a.indexOf(item) === -1) a.push(item);
/******/ 				}
/******/ 			}
/******/ 		
/******/ 			// at begin all updates modules are outdated
/******/ 			// the "outdated" status can propagate to parents if they don't accept the children
/******/ 			var outdatedDependencies = {};
/******/ 			var outdatedModules = [];
/******/ 			var appliedUpdate = {};
/******/ 		
/******/ 			var warnUnexpectedRequire = function warnUnexpectedRequire(module) {
/******/ 				console.warn(
/******/ 					"[HMR] unexpected require(" + module.id + ") to disposed module"
/******/ 				);
/******/ 			};
/******/ 		
/******/ 			for (var moduleId in currentUpdate) {
/******/ 				if (__webpack_require__.o(currentUpdate, moduleId)) {
/******/ 					var newModuleFactory = currentUpdate[moduleId];
/******/ 					/** @type {TODO} */
/******/ 					var result;
/******/ 					if (newModuleFactory) {
/******/ 						result = getAffectedModuleEffects(moduleId);
/******/ 					} else {
/******/ 						result = {
/******/ 							type: "disposed",
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					/** @type {Error|false} */
/******/ 					var abortError = false;
/******/ 					var doApply = false;
/******/ 					var doDispose = false;
/******/ 					var chainInfo = "";
/******/ 					if (result.chain) {
/******/ 						chainInfo = "\nUpdate propagation: " + result.chain.join(" -> ");
/******/ 					}
/******/ 					switch (result.type) {
/******/ 						case "self-declined":
/******/ 							if (options.onDeclined) options.onDeclined(result);
/******/ 							if (!options.ignoreDeclined)
/******/ 								abortError = new Error(
/******/ 									"Aborted because of self decline: " +
/******/ 										result.moduleId +
/******/ 										chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "declined":
/******/ 							if (options.onDeclined) options.onDeclined(result);
/******/ 							if (!options.ignoreDeclined)
/******/ 								abortError = new Error(
/******/ 									"Aborted because of declined dependency: " +
/******/ 										result.moduleId +
/******/ 										" in " +
/******/ 										result.parentId +
/******/ 										chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "unaccepted":
/******/ 							if (options.onUnaccepted) options.onUnaccepted(result);
/******/ 							if (!options.ignoreUnaccepted)
/******/ 								abortError = new Error(
/******/ 									"Aborted because " + moduleId + " is not accepted" + chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "accepted":
/******/ 							if (options.onAccepted) options.onAccepted(result);
/******/ 							doApply = true;
/******/ 							break;
/******/ 						case "disposed":
/******/ 							if (options.onDisposed) options.onDisposed(result);
/******/ 							doDispose = true;
/******/ 							break;
/******/ 						default:
/******/ 							throw new Error("Unexception type " + result.type);
/******/ 					}
/******/ 					if (abortError) {
/******/ 						return {
/******/ 							error: abortError
/******/ 						};
/******/ 					}
/******/ 					if (doApply) {
/******/ 						appliedUpdate[moduleId] = newModuleFactory;
/******/ 						addAllToSet(outdatedModules, result.outdatedModules);
/******/ 						for (moduleId in result.outdatedDependencies) {
/******/ 							if (__webpack_require__.o(result.outdatedDependencies, moduleId)) {
/******/ 								if (!outdatedDependencies[moduleId])
/******/ 									outdatedDependencies[moduleId] = [];
/******/ 								addAllToSet(
/******/ 									outdatedDependencies[moduleId],
/******/ 									result.outdatedDependencies[moduleId]
/******/ 								);
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 					if (doDispose) {
/******/ 						addAllToSet(outdatedModules, [result.moduleId]);
/******/ 						appliedUpdate[moduleId] = warnUnexpectedRequire;
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 			currentUpdate = undefined;
/******/ 		
/******/ 			// Store self accepted outdated modules to require them later by the module system
/******/ 			var outdatedSelfAcceptedModules = [];
/******/ 			for (var j = 0; j < outdatedModules.length; j++) {
/******/ 				var outdatedModuleId = outdatedModules[j];
/******/ 				if (
/******/ 					__webpack_require__.c[outdatedModuleId] &&
/******/ 					__webpack_require__.c[outdatedModuleId].hot._selfAccepted &&
/******/ 					// removed self-accepted modules should not be required
/******/ 					appliedUpdate[outdatedModuleId] !== warnUnexpectedRequire &&
/******/ 					// when called invalidate self-accepting is not possible
/******/ 					!__webpack_require__.c[outdatedModuleId].hot._selfInvalidated
/******/ 				) {
/******/ 					outdatedSelfAcceptedModules.push({
/******/ 						module: outdatedModuleId,
/******/ 						require: __webpack_require__.c[outdatedModuleId].hot._requireSelf,
/******/ 						errorHandler: __webpack_require__.c[outdatedModuleId].hot._selfAccepted
/******/ 					});
/******/ 				}
/******/ 			}
/******/ 		
/******/ 			var moduleOutdatedDependencies;
/******/ 		
/******/ 			return {
/******/ 				dispose: function () {
/******/ 					currentUpdateRemovedChunks.forEach(function (chunkId) {
/******/ 						delete installedChunks[chunkId];
/******/ 					});
/******/ 					currentUpdateRemovedChunks = undefined;
/******/ 		
/******/ 					var idx;
/******/ 					var queue = outdatedModules.slice();
/******/ 					while (queue.length > 0) {
/******/ 						var moduleId = queue.pop();
/******/ 						var module = __webpack_require__.c[moduleId];
/******/ 						if (!module) continue;
/******/ 		
/******/ 						var data = {};
/******/ 		
/******/ 						// Call dispose handlers
/******/ 						var disposeHandlers = module.hot._disposeHandlers;
/******/ 						for (j = 0; j < disposeHandlers.length; j++) {
/******/ 							disposeHandlers[j].call(null, data);
/******/ 						}
/******/ 						__webpack_require__.hmrD[moduleId] = data;
/******/ 		
/******/ 						// disable module (this disables requires from this module)
/******/ 						module.hot.active = false;
/******/ 		
/******/ 						// remove module from cache
/******/ 						delete __webpack_require__.c[moduleId];
/******/ 		
/******/ 						// when disposing there is no need to call dispose handler
/******/ 						delete outdatedDependencies[moduleId];
/******/ 		
/******/ 						// remove "parents" references from all children
/******/ 						for (j = 0; j < module.children.length; j++) {
/******/ 							var child = __webpack_require__.c[module.children[j]];
/******/ 							if (!child) continue;
/******/ 							idx = child.parents.indexOf(moduleId);
/******/ 							if (idx >= 0) {
/******/ 								child.parents.splice(idx, 1);
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// remove outdated dependency from module children
/******/ 					var dependency;
/******/ 					for (var outdatedModuleId in outdatedDependencies) {
/******/ 						if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
/******/ 							module = __webpack_require__.c[outdatedModuleId];
/******/ 							if (module) {
/******/ 								moduleOutdatedDependencies =
/******/ 									outdatedDependencies[outdatedModuleId];
/******/ 								for (j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 									dependency = moduleOutdatedDependencies[j];
/******/ 									idx = module.children.indexOf(dependency);
/******/ 									if (idx >= 0) module.children.splice(idx, 1);
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 				},
/******/ 				apply: function (reportError) {
/******/ 					// insert new code
/******/ 					for (var updateModuleId in appliedUpdate) {
/******/ 						if (__webpack_require__.o(appliedUpdate, updateModuleId)) {
/******/ 							__webpack_require__.m[updateModuleId] = appliedUpdate[updateModuleId];
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// run new runtime modules
/******/ 					for (var i = 0; i < currentUpdateRuntime.length; i++) {
/******/ 						currentUpdateRuntime[i](__webpack_require__);
/******/ 					}
/******/ 		
/******/ 					// call accept handlers
/******/ 					for (var outdatedModuleId in outdatedDependencies) {
/******/ 						if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
/******/ 							var module = __webpack_require__.c[outdatedModuleId];
/******/ 							if (module) {
/******/ 								moduleOutdatedDependencies =
/******/ 									outdatedDependencies[outdatedModuleId];
/******/ 								var callbacks = [];
/******/ 								var dependenciesForCallbacks = [];
/******/ 								for (var j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 									var dependency = moduleOutdatedDependencies[j];
/******/ 									var acceptCallback =
/******/ 										module.hot._acceptedDependencies[dependency];
/******/ 									if (acceptCallback) {
/******/ 										if (callbacks.indexOf(acceptCallback) !== -1) continue;
/******/ 										callbacks.push(acceptCallback);
/******/ 										dependenciesForCallbacks.push(dependency);
/******/ 									}
/******/ 								}
/******/ 								for (var k = 0; k < callbacks.length; k++) {
/******/ 									try {
/******/ 										callbacks[k].call(null, moduleOutdatedDependencies);
/******/ 									} catch (err) {
/******/ 										if (options.onErrored) {
/******/ 											options.onErrored({
/******/ 												type: "accept-errored",
/******/ 												moduleId: outdatedModuleId,
/******/ 												dependencyId: dependenciesForCallbacks[k],
/******/ 												error: err
/******/ 											});
/******/ 										}
/******/ 										if (!options.ignoreErrored) {
/******/ 											reportError(err);
/******/ 										}
/******/ 									}
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// Load self accepted modules
/******/ 					for (var o = 0; o < outdatedSelfAcceptedModules.length; o++) {
/******/ 						var item = outdatedSelfAcceptedModules[o];
/******/ 						var moduleId = item.module;
/******/ 						try {
/******/ 							item.require(moduleId);
/******/ 						} catch (err) {
/******/ 							if (typeof item.errorHandler === "function") {
/******/ 								try {
/******/ 									item.errorHandler(err);
/******/ 								} catch (err2) {
/******/ 									if (options.onErrored) {
/******/ 										options.onErrored({
/******/ 											type: "self-accept-error-handler-errored",
/******/ 											moduleId: moduleId,
/******/ 											error: err2,
/******/ 											originalError: err
/******/ 										});
/******/ 									}
/******/ 									if (!options.ignoreErrored) {
/******/ 										reportError(err2);
/******/ 									}
/******/ 									reportError(err);
/******/ 								}
/******/ 							} else {
/******/ 								if (options.onErrored) {
/******/ 									options.onErrored({
/******/ 										type: "self-accept-errored",
/******/ 										moduleId: moduleId,
/******/ 										error: err
/******/ 									});
/******/ 								}
/******/ 								if (!options.ignoreErrored) {
/******/ 									reportError(err);
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					return outdatedModules;
/******/ 				}
/******/ 			};
/******/ 		}
/******/ 		__webpack_require__.hmrI.jsonp = function (moduleId, applyHandlers) {
/******/ 			if (!currentUpdate) {
/******/ 				currentUpdate = {};
/******/ 				currentUpdateRuntime = [];
/******/ 				currentUpdateRemovedChunks = [];
/******/ 				applyHandlers.push(applyHandler);
/******/ 			}
/******/ 			if (!__webpack_require__.o(currentUpdate, moduleId)) {
/******/ 				currentUpdate[moduleId] = __webpack_require__.m[moduleId];
/******/ 			}
/******/ 		};
/******/ 		__webpack_require__.hmrC.jsonp = function (
/******/ 			chunkIds,
/******/ 			removedChunks,
/******/ 			removedModules,
/******/ 			promises,
/******/ 			applyHandlers,
/******/ 			updatedModulesList
/******/ 		) {
/******/ 			applyHandlers.push(applyHandler);
/******/ 			currentUpdateChunks = {};
/******/ 			currentUpdateRemovedChunks = removedChunks;
/******/ 			currentUpdate = removedModules.reduce(function (obj, key) {
/******/ 				obj[key] = false;
/******/ 				return obj;
/******/ 			}, {});
/******/ 			currentUpdateRuntime = [];
/******/ 			chunkIds.forEach(function (chunkId) {
/******/ 				if (
/******/ 					__webpack_require__.o(installedChunks, chunkId) &&
/******/ 					installedChunks[chunkId] !== undefined
/******/ 				) {
/******/ 					promises.push(loadUpdateChunk(chunkId, updatedModulesList));
/******/ 					currentUpdateChunks[chunkId] = true;
/******/ 				}
/******/ 			});
/******/ 			if (__webpack_require__.f) {
/******/ 				__webpack_require__.f.jsonpHmr = function (chunkId, promises) {
/******/ 					if (
/******/ 						currentUpdateChunks &&
/******/ 						!__webpack_require__.o(currentUpdateChunks, chunkId) &&
/******/ 						__webpack_require__.o(installedChunks, chunkId) &&
/******/ 						installedChunks[chunkId] !== undefined
/******/ 					) {
/******/ 						promises.push(loadUpdateChunk(chunkId));
/******/ 						currentUpdateChunks[chunkId] = true;
/******/ 					}
/******/ 				};
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.hmrM = () => {
/******/ 			if (typeof fetch === "undefined") throw new Error("No browser support: need fetch API");
/******/ 			return fetch(__webpack_require__.p + __webpack_require__.hmrF()).then((response) => {
/******/ 				if(response.status === 404) return; // no update available
/******/ 				if(!response.ok) throw new Error("Failed to fetch update manifest " + response.statusText);
/******/ 				return response.json();
/******/ 			});
/******/ 		};
/******/ 		
/******/ 		// no deferred startup
/******/ 		
/******/ 		// no jsonp function
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	// module cache are used so entry inlining is disabled
/******/ 	// startup
/******/ 	// Load entry module
/******/ 	__webpack_require__("./src/index.js");
/******/ })()
;