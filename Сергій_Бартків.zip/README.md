# Javascript: Rocket Game 

## Application Demo: 

Located in `public` folder

## Project Specifications

**Commands**

- install: 
```
yarn
```

- run: 
```
yarn start
```
Runs the app in the development mode on [http://localhost:3000](http://localhost:3000)

- build: 
```
yarn build
```
